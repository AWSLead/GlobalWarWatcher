'use strict';
const TYPE_MAP={weapons:{label:'Weapons',cls:'tw'},actors:{label:'Shared Actors',cls:'tao'},economic:{label:'Economic',cls:'tec'},political:{label:'Political',cls:'tpl'},military:{label:'Mil. Support',cls:'tms'},proxy:{label:'Proxy War',cls:'tpx'}};
const NEWS_QUERIES={'iran-us-israel':'Iran US Israel war 2026 Operation Epic Fury','ukraine-russia':'Ukraine Russia war ceasefire 2026','israel-hamas-gaza':'Gaza Israel Hamas war 2026','yemen-houthis':'Yemen Houthi Red Sea attack 2026','sudan-civil-war':'Sudan civil war SAF RSF 2026','myanmar-civil-war':'Myanmar civil war junta resistance 2026','drc-m23':'DRC Congo M23 Goma Rwanda 2026','somalia-alshabaab':'Somalia Al Shabaab attack 2026'};
const WAR_PAIRS=[
  [{id:'iran-us-israel',name:'Iran-US/Israel War 2026 (Operation Epic Fury, Day 10+)'},{id:'ukraine-russia',name:'Russia-Ukraine War (Day 1474, ceasefire talks stalled)'}],
  [{id:'israel-hamas-gaza',name:'Gaza/Israel-Hamas War (Day 519, IDF two-front war)'},{id:'yemen-houthis',name:'Yemen/Houthi Red Sea Conflict (coordinating with Iran)'}],
  [{id:'sudan-civil-war',name:'Sudan Civil War (SAF vs RSF, 150k dead)'},{id:'myanmar-civil-war',name:'Myanmar Civil War (Junta vs resistance, Operation 1027 gains)'}],
  [{id:'drc-m23',name:'DRC Eastern Congo M23 War (Goma fell Jan 2026)'},{id:'somalia-alshabaab',name:'Somalia Al-Shabaab insurgency (Total War stalled)'}],
];
const GLOBAL_CONNECTIONS=[
  {w1:'Iran–US/Israel War',w2:'Gaza / Hamas War',types:['actors','military','proxy'],str:'direct',desc:"Hamas, Hezbollah, and Houthis are Iranian proxies activated in coordination with Operation Epic Fury. Netanyahu fights two simultaneous fronts."},
  {w1:'Iran–US/Israel War',w2:'Yemen / Houthis',types:['proxy','weapons','actors'],str:'direct',desc:"Houthis are Iran's most active proxy — coordinating Red Sea disruption and missile launches at Israel alongside IRGC operations."},
  {w1:'Iran–US/Israel War',w2:'Russia–Ukraine War',types:['political','actors','economic'],str:'direct',desc:"Russia provides Iran real-time targeting intelligence. Ukraine talks frozen; Russia profits at $120 Brent."},
  {w1:'Gaza / Hamas War',w2:'Yemen / Houthis',types:['proxy','political','weapons'],str:'direct',desc:"Houthis began Red Sea campaign in solidarity with Hamas; both under Iran's axis of resistance with shared weapons and command."},
  {w1:'Russia–Ukraine War',w2:'Sudan Civil War',types:['weapons','actors'],str:'indirect',desc:"Wagner Group (Africa Corps) supported RSF with weapons — Russia extending proxy warfare across Africa."},
  {w1:'Russia–Ukraine War',w2:'Myanmar Civil War',types:['weapons'],str:'indirect',desc:"Russia supplies Myanmar junta with fighter jets and drones — same global weapons-for-influence pipeline."},
  {w1:'Iran–US/Israel War',w2:'Sudan Civil War',types:['weapons'],str:'indirect',desc:"Iran supplying SAF with Shahed-variant drones despite being at war itself — multi-theater proxy capability."},
  {w1:'DRC / Congo War',w2:'Somalia / Al-Shabaab',types:['actors','economic'],str:'indirect',desc:"Both rely on AU peacekeeping from the same troop contributors (Uganda, South Africa) — both consuming AU capacity simultaneously."},
  {w1:'Yemen / Houthis',w2:'Somalia / Al-Shabaab',types:['economic'],str:'indirect',desc:"Red Sea disruption raises East African food import costs, worsening Somalia's food security and fueling al-Shabaab recruitment."},
  {w1:'Sudan Civil War',w2:'DRC / Congo War',types:['economic','actors'],str:'indirect',desc:"Both involve Gulf states competing for African mineral wealth — UAE in Sudan (gold), Rwanda-M23 in DRC (coltan)."},
];

// ── Markets ──
const MARKETS=[
  {sym:'BZ=F',    lbl:'Brent Crude', u:'$',s:'/bbl' },
  {sym:'CL=F',    lbl:'WTI Crude',   u:'$',s:'/bbl' },
  {sym:'GC=F',    lbl:'Gold',        u:'$',s:'/oz'  },
  {sym:'SI=F',    lbl:'Silver',      u:'$',s:'/oz'  },
  {sym:'^GSPC',   lbl:'S&P 500',     u:'', s:''     },
  {sym:'000300.SS',lbl:'CSI 300',    u:'', s:''     },
  {sym:'^STOXX50E',lbl:'Euro Stoxx', u:'', s:''     },
  {sym:'^BVSP',   lbl:'Bovespa',     u:'', s:''     },
  {sym:'^NSEI',   lbl:'Nifty 50',    u:'', s:''     },
  {sym:'NG=F',    lbl:'Nat Gas',     u:'$',s:'/mmbtu'},
  {sym:'EURUSD=X',lbl:'EUR/USD',     u:'', s:''     },
  {sym:'USDRUB=X',lbl:'USD/RUB',     u:'', s:''     },
  {sym:'^VIX',    lbl:'VIX Fear',    u:'', s:''     },
];

const CHOKEPOINTS=[
  {name:'Strait of Hormuz',status:'CRITICAL',cls:'cs-crit',pct:'~5% open',detail:'~95% shipping halted — Iran war'},
  {name:'Red Sea / Suez',  status:'SEVERE',  cls:'cs-warn',pct:'−60% traffic',detail:'Houthi attacks ongoing'},
  {name:'Black Sea',       status:'PARTIAL', cls:'cs-warn',pct:'~45% capacity',detail:'Ukraine war grain corridor tensions'},
  {name:'Strait of Malacca',status:'NORMAL', cls:'cs-ok',  pct:'100%',detail:'No active threat'},
  {name:'Panama Canal',    status:'LIMITED', cls:'cs-warn',pct:'−20% capacity',detail:'Drought-level restrictions remain'},
];

// ── Source credibility ──
const SRC_H=['reuters','associated press','ap news','afp','bbc','new york times','nytimes','wsj','wall street journal','financial times','bloomberg','guardian','the guardian','npr','dpa','france24','al jazeera english','der spiegel','le monde'];
const SRC_S=['rt','russia today','sputnik','presstv','press tv','xinhua','cgtn','tass','ria novosti','al-manar','al mayadeen','irgc','tasnim','mehr news','isna'];
function srcTier(n){if(!n)return'm';const l=n.toLowerCase();if(SRC_S.some(x=>l.includes(x)))return's';if(SRC_H.some(x=>l.includes(x)))return'h';return'm';}

// ── Rumors ──
const RUMORS={
  'iran-us-israel':[
    {s:'unconfirmed',c:"Iran moved the majority of its 60%-enriched uranium stockpile to an undisclosed underground facility before strikes began, preserving nuclear breakout capacity.",src:'IRGC-linked Telegram / MEK sources',d:'Mar 3, 2026'},
    {s:'disputed',c:"Israeli F-35Is dropped B61-12 nuclear-capable bunker-buster variants on Fordow — US denies, Israel has not commented.",src:'Anonymous Western intel via Der Spiegel',d:'Mar 1, 2026'},
    {s:'unconfirmed',c:"Mojtaba Khamenei's election as Supreme Leader was contested — multiple senior IRGC commanders opposed the father-to-son succession.",src:'MEK opposition / unnamed Iranian officials',d:'Mar 9, 2026'},
    {s:'disputed',c:"The Kuwait F/A-18 that shot down 3 US F-15Es on March 2 was electronically hijacked via an Iranian cyber operation targeting IFF transponders.",src:'Anonymous US Air Force officials',d:'Mar 5, 2026'},
  ],
  'ukraine-russia':[
    {s:'unconfirmed',c:"Russia pre-positioned tactical nuclear warheads at Brest and Mazyr in Belarus — assessed as coercive signaling ahead of ceasefire talks.",src:'UK Defence Intelligence',d:'Feb 20, 2026'},
    {s:'disputed',c:"Zelensky offered in back-channel Abu Dhabi talks to cede de facto Russian-controlled Donbas in exchange for NATO membership.",src:'Middle Eastern diplomats via Le Monde',d:'Feb 15, 2026'},
    {s:'debunked',c:"Putin suffered a major stroke in January 2026 — official appearances are deepfake composites.",src:'Various Telegram channels / pro-Ukraine accounts',d:'Jan 12, 2026'},
  ],
  'israel-hamas-gaza':[
    {s:'unconfirmed',c:"Hamas killed at least 14 hostages during the Iran war escalation to prevent rescue operations. Mossad believes 100+ hostages still alive.",src:'Israeli intelligence sources via Haaretz',d:'Mar 6, 2026'},
    {s:'disputed',c:"IDF used white phosphorus munitions in urban areas of Rafah. Israel denies. Amnesty International and UNRWA indicate evidence from field reports.",src:'Amnesty International / UNRWA / IDF denial',d:'Feb 2026'},
  ],
  'yemen-houthis':[
    {s:'unconfirmed',c:"Saudi Arabia opened a secret back-channel to Houthi leadership in Muscat, offering to recognize Houthi governance in northern Yemen in exchange for halting Red Sea attacks.",src:'Yemeni analysts / unnamed Saudi officials',d:'Mar 4, 2026'},
    {s:'disputed',c:"Houthis acquired Chinese-made YJ-12B supersonic anti-ship missiles — significantly increasing threat to US carrier strike groups.",src:'US CENTCOM intelligence assessment leak',d:'Feb 28, 2026'},
  ],
  'sudan-civil-war':[
    {s:'unconfirmed',c:"RSF commander Hemeti has relocated to UAE amid an internal RSF power struggle.",src:'Al-Hadath / Sudanese political opposition',d:'Feb 25, 2026'},
    {s:'confirmed',c:"UAE is the primary financial backer of RSF, purchasing RSF-controlled gold at below-market rates — documented by UN Panel of Experts.",src:'UN Panel of Experts on Sudan',d:'Jan 2026'},
  ],
  'myanmar-civil-war':[
    {s:'disputed',c:"Min Aung Hlaing is terminally ill — absence from public events since December 2025 fuels succession speculation.",src:'Irrawaddy / pro-democracy Burmese outlets',d:'Jan 2026'},
  ],
  'drc-m23':[
    {s:'confirmed',c:"Rwandan Defence Force soldiers are operating in eastern DRC in direct combat roles — confirmed by US, EU, and UN investigations.",src:'UN Group of Experts on DRC / US State Dept',d:'2025–2026'},
  ],
  'somalia-alshabaab':[
    {s:'unconfirmed',c:"Ethiopian forces informally notified the AU of intent to withdraw from AUSSOM by end-2026 — would catastrophically weaken the mission.",src:'AU diplomatic circles via Reuters',d:'Mar 2026'},
  ],
};

// ── Trading data per war ──
const TRADING={
  'iran-us-israel':{
    risk:92,
    note:"Highest single-conflict market impact since 1973. Hormuz closure cuts ~20% of global oil supply. Every week closed adds ~$5–8/bbl. Monitor IRGC fracture signals and China back-channel daily.",
    signals:[
      {dir:'long',asset:'Brent Crude / WTI',tickers:['BZ=F','CL=F','UCO','USO'],reason:'Hormuz ~95% blocked. Structurally bullish until reopening. Entry on any dip below $115. Stop-loss on credible ceasefire.'},
      {dir:'long',asset:'Gold',tickers:['GC=F','GLD','IAU'],reason:'Classic safe-haven + USD weakness. Nuclear escalation rhetoric adds tail premium. Watch $3,200 resistance; break = run to $3,400+.'},
      {dir:'long',asset:'Natural Gas (TTF / HH)',tickers:['NG=F','UNG','BOIL'],reason:'Qatar Ras Laffan offline = 20% global LNG gone. European TTF most exposed. Bullish until restart confirmed.'},
      {dir:'long',asset:'Defense & Aerospace',tickers:['LMT','RTX','NOC','GD','ITA'],reason:'Munitions resupply at war pace. F-35 battle-proven. JASSM, ATACMS, Iron Dome production surge.'},
      {dir:'short',asset:'Airlines / Consumer Discretionary',tickers:['DAL','UAL','AAL','XLY'],reason:'Jet fuel +40% vs pre-war. Middle East / Asia route demand collapsing. Margin compression near-certain.'},
      {dir:'short',asset:'S&P 500',tickers:['^GSPC','SPY','SH'],reason:'Sustained closure = CPI spike = Fed hawkish again. P/E compression at 22x unsustainable if rates reprice.'},
      {dir:'watch',asset:'Silver',tickers:['SI=F','SLV'],reason:'Safe haven + industrial (solar, EV, defense electronics). Outperforms gold in sustained risk-off.'},
      {dir:'watch',asset:'Defense ETFs',tickers:['ITA','XAR','KTOS'],reason:'US defense spending increasing. Boeing, Lockheed, RTX direct beneficiaries.'},
    ],
    scenarios:[
      {name:'Ceasefire within 30d',prob:'15%',cls:'sp-b',mkt:'Brent −$25–35, Gold −5%, SPY +4–6%. Sharp reversal.'},
      {name:'Stalemate 1–3 months',prob:'55%',cls:'sp-s',mkt:'Brent $100–120 range. Gold holds $3,100+. Volatility elevated.'},
      {name:'Escalation / Iran nuclear',prob:'30%',cls:'sp-e',mkt:'Brent $140–160+. Gold $3,500+. SPY −15%. Full risk-off.'},
    ],
    sanctions:[
      {target:'Iran (full economy)',by:'US / EU / UK',status:'act'},
      {target:'IRGC + subsidiaries',by:'US OFAC + EU',status:'act'},
      {target:'Russian energy (war-adjacent)',by:'G7',status:'act'},
      {target:'Houthi leadership',by:'US Treasury',status:'act'},
    ],
  },
  'ukraine-russia':{
    risk:58,
    note:"Russia is the surprise economic beneficiary — $120 Brent adds ~$200M/day windfall cushioning sanctions. Ukraine market impact is secondary, but a ceasefire deal would be the largest reconstruction trade in a generation.",
    signals:[
      {dir:'long',asset:'European Natural Gas (TTF)',tickers:['NG=F','UNG','BOIL'],reason:'Iran + Ukraine both pressuring EU energy. Winter 2026 restocking at risk. Structural premium through summer.'},
      {dir:'long',asset:'Wheat / Corn futures',tickers:['ZW=F','ZC=F','WEAT','CORN'],reason:'Ukraine = 10% global wheat, 15% corn. Black Sea corridor tensions. Escalation = +10–20% spike risk.'},
      {dir:'long',asset:'Defense sector',tickers:['LMT','RTX','KTOS','AVAV','ITA'],reason:'European NATO rearmament accelerating. Germany 2% GDP = €80B+/yr. Drones, air defense, artillery in structural demand.'},
      {dir:'watch',asset:'Ukraine reconstruction (long-term)',tickers:['EBRD bonds','UAH'],reason:'Peace deal = $500B+ reconstruction. Watch Ukraine sovereign debt and EBRD reconstruction exposure.'},
      {dir:'short',asset:'German DAX / European Industrials',tickers:['^GDAXI','EWG'],reason:'Energy cost burden eroding German industrial competitiveness. BASF, ThyssenKrupp, auto OEMs all margin-impaired.'},
      {dir:'watch',asset:'Wheat as ceasefire hedge',tickers:['ZW=F','WEAT'],reason:'Ceasefire = grain corridor resumes = wheat flash crash. Short wheat as ceasefire scenario hedge.'},
    ],
    scenarios:[
      {name:'Ceasefire deal',prob:'20%',cls:'sp-b',mkt:'Wheat −15%, DAX +8%, Ukrainian bonds rally. Reconstruction ETF opportunity.'},
      {name:'Frozen conflict',prob:'55%',cls:'sp-s',mkt:'TTF elevated. Wheat range-bound. Defense stocks continue strong.'},
      {name:'Escalation',prob:'25%',cls:'sp-e',mkt:'TTF +50%, Wheat +25%, European equities −10%.'},
    ],
    sanctions:[
      {target:'Russian Central Bank',by:'US / EU / UK / Canada',status:'act'},
      {target:'Russian energy — $60 oil price cap',by:'G7 / EU',status:'act'},
      {target:'Russian SWIFT access',by:'EU / US',status:'act'},
      {target:'Belarus (Lukashenko regime)',by:'EU / US',status:'act'},
    ],
  },
  'israel-hamas-gaza':{
    risk:44,
    note:"Direct market impact now secondary to Iran war. The tail risk is a full Hezbollah escalation. Primary tradeable: Israeli equities, shekel, and regional tourism recovery plays.",
    signals:[
      {dir:'watch',asset:'Tel Aviv Stock Exchange (TA-35)',tickers:['EIS','ISDCY'],reason:'Two-front war premium baked in. Iran ceasefire + Gaza deal = TA-35 relief rally of 12–18%. Escalation = sharp selloff.'},
      {dir:'watch',asset:'Israeli Shekel (USD/ILS)',tickers:['ILS=X'],reason:'ILS down ~8% since Oct 7, 2023. Ceasefire = recovery to 3.55–3.60 range.'},
      {dir:'watch',asset:'Israeli tech sector',tickers:['NICE','CHKP','CYBR','MNDY'],reason:'War premium compressed multiples. Ceasefire = re-rating. Cyber stocks benefit from elevated global threat environment.'},
      {dir:'avoid',asset:'Gaza reconstruction instruments',tickers:[],reason:'No viable governance structure. Zero rule of law. Any fund claiming Gaza reconstruction exposure is speculative.'},
    ],
    scenarios:[
      {name:'Gaza deal + Iran ceasefire',prob:'15%',cls:'sp-b',mkt:'TA-35 +15%, ILS +5%, regional tourism recovery.'},
      {name:'Continued stalemate',prob:'60%',cls:'sp-s',mkt:'Status quo. TA-35 range-bound. ILS weak.'},
      {name:'Hezbollah full war',prob:'25%',cls:'sp-e',mkt:'TA-35 −25%, ILS −12%, oil spike, safe havens surge.'},
    ],
    sanctions:[
      {target:'Hamas (terrorist designation)',by:'US / EU / UK / AU',status:'act'},
      {target:'PIJ (Palestinian Islamic Jihad)',by:'US / EU',status:'act'},
      {target:'Settlement-linked entities',by:'EU (partial)',status:'par'},
    ],
  },
  'yemen-houthis':{
    risk:75,
    note:"Second-highest global market impact. Combined Houthi + Hormuz = worst simultaneous chokepoint crisis in modern history. Container rates, tanker stocks, and war risk insurance are the primary trading instruments.",
    signals:[
      {dir:'long',asset:'Container shipping stocks',tickers:['ZIM','CMRE','MATX'],reason:'Cape of Good Hope rerouting = +10–14 days/voyage. +$300K–$1M extra cost/trip. Rate premium sustains until Red Sea clears.'},
      {dir:'long',asset:'Tanker stocks',tickers:['FRO','DHT','STNG','TK'],reason:'Oil tanker rerouting = longer voyages = higher day rates. Tanker utilization near peak.'},
      {dir:'long',asset:'War risk insurance / reinsurance',tickers:['MKL','RLI'],reason:"Red Sea war risk premium +300%. Lloyd's syndicates and specialty reinsurers direct beneficiaries."},
      {dir:'short',asset:'European fast fashion / retailers',tickers:['ITX.MC','HM-B.ST','MKS.L'],reason:'Inventory cycle broken. +3 weeks delivery delay. Inditex (Zara), H&M, M&S exposed.'},
      {dir:'watch',asset:'Egypt sovereign / EGP',tickers:['EGX30'],reason:'Suez Canal revenue −50% = Egypt losing ~$800M/month. IMF program under stress. EGP devaluation risk.'},
      {dir:'watch',asset:'Saudi Aramco / Saudi equities',tickers:['2222.SR','KSA'],reason:'Houthi ceasefire = Saudi normalization = Aramco re-rating. Saudi back-channel rumored.'},
    ],
    scenarios:[
      {name:'Houthi deal (Iran ceasefire)',prob:'35%',cls:'sp-b',mkt:'Shipping rates −40%, Suez resumes, retailers recover.'},
      {name:'Sustained attacks',prob:'50%',cls:'sp-s',mkt:'Shipping premium holds. Egypt stress continues.'},
      {name:'Major warship sinking',prob:'15%',cls:'sp-e',mkt:'Insurance freeze, shipping rates +100%, oil spike.'},
    ],
    sanctions:[
      {target:'Houthi leadership (SDT)',by:'US Treasury',status:'act'},
      {target:'Iranian weapons pipeline',by:'US OFAC',status:'act'},
    ],
  },
  'sudan-civil-war':{
    risk:28,
    note:"Low direct market impact but important for gold markets (UAE-RSF gold smuggling distorts physical supply data) and East Africa frontier debt. Contagion risk is underpriced by most EM investors.",
    signals:[
      {dir:'watch',asset:'Gold (physical vs paper)',tickers:['GC=F','GLD','PHYS'],reason:'RSF controls major Sudanese mines. Smuggled gold through UAE distorts physical supply data. Watch paper/physical spread.'},
      {dir:'watch',asset:'East Africa sovereign debt',tickers:['CEMB','ESGE'],reason:'Sudan collapse radiating into Chad, CAR, Ethiopia. EM bond investors underpricing regional contagion.'},
      {dir:'watch',asset:'UAE financial institutions',tickers:['FAB.AD','DIB.DU'],reason:'UAE banks have Sudan/RSF gold exposure. Sanctions escalation on UAE gold traders = compliance risk.'},
      {dir:'avoid',asset:'Sudan sovereign / RSF-linked instruments',tickers:[],reason:'No functioning government. Complete capital controls. Zero legal recourse. Hard avoid.'},
    ],
    scenarios:[
      {name:'Negotiated partition',prob:'30%',cls:'sp-b',mkt:'Limited market impact. East Africa stability marginal improvement.'},
      {name:'Prolonged stalemate',prob:'55%',cls:'sp-s',mkt:'Gold smuggling continues suppressing official data.'},
      {name:'State collapse / famine',prob:'15%',cls:'sp-e',mkt:'East Africa EM spread widening, food commodity spike.'},
    ],
    sanctions:[
      {target:'RSF / Gen. Dagalo (Hemeti)',by:'US / EU / UK',status:'new'},
      {target:'SAF leadership',by:'EU (partial)',status:'par'},
      {target:'UAE-linked gold traders',by:'Under investigation',status:'par'},
    ],
  },
  'myanmar-civil-war':{
    risk:35,
    note:"Critical for rare earth and heavy mineral supply chains. Myanmar is the world's largest supplier of heavy rare earths essential for EV motors, wind turbines, and defense systems. Systematically underpriced by most commodity traders.",
    signals:[
      {dir:'long',asset:'Rare Earth ETFs',tickers:['REMX','MP','UAMY'],reason:'Myanmar = #1 heavy rare earth supplier globally. Junta losing control of mining regions. EV and defense demand inelastic. Supply shock underpriced.'},
      {dir:'long',asset:'Australian rare earth miners',tickers:['LYC.AX','ILU.AX','ARU.AX'],reason:'Myanmar supply disruption = premium for non-conflict sources. Australian miners are cleanest alternative.'},
      {dir:'watch',asset:'Chinese rare earth processors',tickers:['600111.SS','000831.SZ'],reason:'China controls >90% of heavy RE processing. Junta collapse = prices spike. Watch for Chinese intervention signals.'},
      {dir:'watch',asset:'EV manufacturers (supply chain risk)',tickers:['TSLA','NIO','BYD','RIVN'],reason:'Dysprosium and terbium essential for EV motors. Shortage = cost inflation for OEMs.'},
      {dir:'avoid',asset:'Myanmar-linked banks / MOGE',tickers:[],reason:'MOGE state oil revenue funds junta. OFAC sanctions exposure. Complete avoidance.'},
    ],
    scenarios:[
      {name:'Junta collapse',prob:'20%',cls:'sp-b',mkt:'RE supply spike, then normalization. REMX +30% short-term.'},
      {name:'Prolonged fragmentation',prob:'60%',cls:'sp-s',mkt:'RE supply gradually impacted. REMX slow grind higher.'},
      {name:'China military intervention',prob:'20%',cls:'sp-e',mkt:'Geopolitical premium. CNH weakens. Taiwan strait risk elevated.'},
    ],
    sanctions:[
      {target:'Military Junta (SAC)',by:'US / EU / UK / Canada',status:'act'},
      {target:'MOGE (Myanmar Oil & Gas Enterprise)',by:'US / EU',status:'act'},
      {target:'Timber / jade exports',by:'US / EU',status:'act'},
    ],
  },
  'drc-m23':{
    risk:55,
    note:"Most important conflict for long-term tech and EV supply chains. DRC produces ~70% of world cobalt and ~30% of tantalum. M23 advancing toward Bukavu puts the entire eastern mining belt under non-state control.",
    signals:[
      {dir:'long',asset:'Cobalt futures / royalty stocks',tickers:['OM.L','CMCL.L','JRVS.L'],reason:'DRC ~70% global cobalt. M23 advance toward Bukavu = direct mine disruption. CATL, Panasonic, Samsung SDI exposed.'},
      {dir:'long',asset:'Alternative cobalt miners',tickers:['BHP','RIO','GLNCY'],reason:'Non-DRC cobalt commands premium. Glencore paradoxically benefits from higher prices offsetting volume risk.'},
      {dir:'long',asset:'Tantalum / coltan alternatives',tickers:['EMH.AX','CAN.AX'],reason:'DRC ~30% global tantalum for electronics capacitors. Australian and Brazilian sources get premium.'},
      {dir:'short',asset:'EV manufacturers (near-term)',tickers:['TSLA','NIO','LI','XPEV'],reason:'Cobalt price spike = battery cost inflation. Thin-margin EV players most exposed.'},
      {dir:'watch',asset:'Glencore',tickers:['GLEN.L','GLNCY'],reason:'Largest single cobalt producer globally. Conflict = price boost vs volume risk. Complex — monitor closely.'},
      {dir:'watch',asset:'Rwanda sovereign',tickers:['RW'],reason:'RDF involvement documented. US Congress sanctions threat. Rwanda bonds = sell on escalation.'},
    ],
    scenarios:[
      {name:'M23 contained',prob:'25%',cls:'sp-b',mkt:'Cobalt normalizes, EV supply chain relief.'},
      {name:'Continued expansion',prob:'55%',cls:'sp-s',mkt:'Cobalt premium sustained. RE alternatives premium holds.'},
      {name:'Rwanda-DRC formal war',prob:'20%',cls:'sp-e',mkt:'Cobalt +40%, TSLA/NIO −10%, humanitarian crisis deepens.'},
    ],
    sanctions:[
      {target:'M23 leadership',by:'US / EU',status:'act'},
      {target:'Rwanda (under consideration)',by:'US Congress / EU',status:'par'},
      {target:'Illegal mineral traders',by:'UN / US OFAC',status:'act'},
    ],
  },
  'somalia-alshabaab':{
    risk:22,
    note:"Minimal direct market impact. Relevant as a compounding factor for Indian Ocean shipping security alongside the Houthi crisis. Al-Shabaab piracy is resurging as naval resources are diverted.",
    signals:[
      {dir:'watch',asset:'East Africa frontier bonds',tickers:['CEMB','ESGE'],reason:'Somalia instability radiates into Kenya, Ethiopia, Tanzania. Frontier investors underpricing regional contagion.'},
      {dir:'watch',asset:'Shipping / Indian Ocean route',tickers:['ZIM','FRO','STNG'],reason:'Al-Shabaab piracy resurging as Houthi crisis diverts Indian Ocean naval resources.'},
      {dir:'watch',asset:'Kenya equities / KES',tickers:['KES=X'],reason:'Al-Shabaab conducts cross-border attacks in Kenya. Tourism sector (major FX earner) vulnerable.'},
      {dir:'avoid',asset:'Somalia sovereign instruments',tickers:[],reason:'No functioning state. Zero fiscal data. No legal framework. Hard avoid.'},
    ],
    scenarios:[
      {name:'Total War succeeds',prob:'15%',cls:'sp-b',mkt:'East Africa stability, Kenya tourism recovery.'},
      {name:'Frozen insurgency',prob:'70%',cls:'sp-s',mkt:'Minimal market impact. Indian Ocean piracy slowly rises.'},
      {name:'AU withdrawal / state collapse',prob:'15%',cls:'sp-e',mkt:'East Africa EM selloff, Indian Ocean insurance spike.'},
    ],
    sanctions:[
      {target:'Al-Shabaab (terrorist designation)',by:'US / EU / UN',status:'act'},
      {target:'Al-Qaeda affiliates',by:'US OFAC / UN 1267',status:'act'},
    ],
  },
};

// ── War data ──
const WARS=[
  {id:'iran-us-israel',name:'Iran–US/Israel War 2026',location:'Middle East / Persian Gulf',startDate:'Feb 28, 2026',dayCount:10,intensity:'high',status:'Active',lat:30,lng:53,
   oneLiner:'Joint US-Israel Operation Epic Fury killed Supreme Leader Khamenei; Iran retaliated against 27 US bases; Hormuz ~95% blocked.',
   side1Name:'US / Israel',side2Name:'Iran / IRGC',side1Score:68,
   battleAssessment:"US/Israel hold air superiority and have degraded Iran's missile capacity by 86% and drones by 73%. Iran's Hormuz stranglehold, intact IRGC command chain, and Russian intelligence support prevent decisive victory.",
   casualties:[{label:'US KIA',val:'8 confirmed',cls:'a'},{label:'US Wounded',val:'31+',cls:''},{label:'Iran KIA',val:'1,332+ official',cls:'r'},{label:'Iran Wounded',val:'6,800+',cls:''},{label:'Civilian Deaths',val:'1,100+',cls:'r'},{label:'Displaced',val:'280,000+',cls:''}],
   casualtyNote:"Iran real toll estimated 3–5× official. Israel: 12–13 civilians killed. Lebanon: 400+ killed.",
   side1Adv:['Air superiority over Tehran','3,000+ targets struck, 43 warships destroyed','F-35 first air-to-air kill (Yak-130)','No US Navy ships struck'],
   side2Adv:['Hormuz ~95% shipping halted','IRGC kill chain intact, no defections','Russia providing targeting intelligence','New Supreme Leader Mojtaba Khamenei — hardline IRGC ties'],
   recentDev:"Day 10+: New Supreme Leader Mojtaba Khamenei elected March 8 under IRGC pressure — father-to-son succession violates revolutionary ideology, only possible under military pressure. CIA arming Kurdish insurgents along Iraq-Iran border. Qatar's Ras Laffan LNG offline — 20% global LNG disrupted. Friendly fire March 2: Kuwait F/A-18 shot down 3 US F-15Es (6 crew survived).",
   leaders:[{name:'Donald Trump',title:'US President',side:'1',bio:'Confirmed major combat operations with regime change objective.'},{name:'Benjamin Netanyahu',title:'Israeli PM',side:'1',bio:'Co-architect of Operation Roaring Lion; managing Gaza and Iran simultaneously.'},{name:'Mojtaba Khamenei',title:'Supreme Leader (Mar 8)',side:'2',bio:'Son of assassinated Khamenei, 56, deep IRGC ties.'},{name:'Gen. Hossein Salami',title:'IRGC Commander',side:'2',bio:'Commands intact IRGC kill chain.'}],
   econMetrics:[{label:'Brent Crude',val:'$120/bbl',change:'+65% since Feb 27',dir:'up'},{label:'US Gas Price',val:'$3.41/gal',change:'+$0.43/wk',dir:'up'},{label:'Hormuz Traffic',val:'~5%',change:'−95% halted',dir:'down'},{label:'Qatar LNG',val:'Offline',change:'20% global LNG',dir:'down'}],
   econOverview:"Hormuz closure is the single largest lever in the global economy. Goldman Sachs projects US CPI could hit 3% if Hormuz stays closed. Russia benefits enormously at $120 Brent. LNG disruption is compounding natural gas pricing globally.",
   side1Allies:[{country:'United Kingdom',role:'Defensive ops authorized'},{country:'France',role:'Defensive use only'},{country:'Gulf States',role:'Base access; Kuwait, Qatar under attack'}],
   side2Allies:[{country:'Russia',role:'Confirmed targeting intelligence'},{country:'Houthis',role:'Red Sea attacks, coordinated'},{country:'Hezbollah',role:'Lebanon front active'}],
   shortTerm:"4-week regime change timeline slipping. IRGC has not fractured. Hormuz closed for weeks. CIA Kurdish insurgency in early stage.",
   mediumTerm:"(A) Frozen stalemate, Hormuz standoff — most likely. (B) Iran concessions if IRGC fractures. (C) Escalation if Russia increases support.",
   wildcards:"IRGC defections, Israeli ground op, Iran strikes on US carriers, China pressuring Iran on Hormuz.",
   outcome:"55%: Prolonged air campaign, Hormuz partially reopens under Chinese pressure within 6 weeks, negotiated standdown short of regime change.",
   connectedTo:[{warId:'israel-hamas-gaza',warName:'Gaza / Hamas War',types:['actors','military'],strength:'direct',desc:'Netanyahu managing two fronts; Hezbollah active in Lebanon alongside Gaza.'},{warId:'ukraine-russia',warName:'Russia–Ukraine War',types:['political','actors'],strength:'direct',desc:'Russia provides Iran targeting intel. Ukraine talks frozen.'},{warId:'yemen-houthis',warName:'Yemen / Houthis',types:['proxy','weapons'],strength:'direct',desc:'Houthis are Iranian proxy coordinating Red Sea attacks.'}],news:[]},
  {id:'ukraine-russia',name:'Russia–Ukraine War',location:'Eastern Europe',startDate:'Feb 24, 2022',dayCount:1474,intensity:'high',status:'Active',lat:49,lng:32,
   oneLiner:"Ceasefire talks stalled as Washington's full attention pivots to Iran; Russia advances in Donbas while exploiting the pause.",
   side1Name:'Ukraine',side2Name:'Russia',side1Score:38,
   battleAssessment:"Russia holds grinding territorial advantage in Donbas, advancing toward Pokrovsk. Coalition of the Willing ceasefire deal was closest since 2022, but US attention shifted entirely to Iran.",
   casualties:[{label:'Ukraine KIA',val:'~60–80K',cls:'a'},{label:'Ukraine Wounded',val:'200,000+',cls:''},{label:'Russia KIA',val:'~120–180K',cls:'r'},{label:'Russia Wounded',val:'350,000+',cls:''},{label:'Civilian Deaths',val:'~12,000+',cls:'r'},{label:'Displaced',val:'6.7 million',cls:''}],
   casualtyNote:"All figures are estimates; official counts are classified. Western intelligence assessments cited.",
   side1Adv:['Western weapons and intelligence (F-16s operational)','35-nation Coalition of the Willing','France/UK pledged military hubs','Strong mobilization narrative'],
   side2Adv:['Territorial momentum in Donbas','$120 Brent crude relieves sanctions pressure','US attention entirely on Iran','Iran intel provision = new leverage vs Washington'],
   recentDev:"Ceasefire talks postponed as Iran crisis consumes all diplomatic bandwidth. Abu Dhabi venue collapsed when Iran attacked UAE. Ukraine drone specialists deployed to Gulf. Russia cushioned by Iran oil windfall — earning an estimated $200M/day extra vs pre-war baseline.",
   leaders:[{name:'Volodymyr Zelensky',title:'Ukrainian President',side:'1',bio:'Confirmed talks postponed; managing 200,000+ AWOL soldiers.'},{name:'Vladimir Putin',title:'Russian President',side:'2',bio:'Exploiting Iran war to relieve economic pressure; providing Iran targeting data as leverage.'}],
   econMetrics:[{label:'Ukraine GDP Loss',val:'~35%',change:'Since 2022',dir:'down'},{label:'Brent (Russia gain)',val:'$120/bbl',change:'+$47 windfall',dir:'up'},{label:'EU Energy Cost',val:'+18%',change:'vs pre-war',dir:'up'},{label:'Russian Reserves',val:'~$600B',change:'Sanctions-frozen',dir:'neutral'}],
   econOverview:"Russia is the unexpected economic winner of the Iran war — $120 Brent cushions sanctions. Ukraine has lost ~35% GDP since 2022. Europe faces compounding energy cost pressure from both conflicts.",
   side1Allies:[{country:'USA',role:'Arms, intel — attention on Iran'},{country:'UK',role:'Military hubs pledged, F-16 training'},{country:'France',role:'Coalition leader'},{country:'EU',role:'$50B+ in aid committed'}],
   side2Allies:[{country:'North Korea',role:'Artillery shells, ~10,000 troops'},{country:'Iran',role:'Shahed drones (pre-2026 war)'},{country:'Belarus',role:'Staging ground'}],
   shortTerm:"Talks frozen 3–6 months. Russia advances slowly in Pokrovsk. Ukraine holds lines but cannot launch major offensive.",
   mediumTerm:"Scenario A (55%): Frozen conflict. Scenario B (25%): US pressure forces bad deal. Scenario C (20%): Iran ends fast, deal closes summer.",
   wildcards:"Ukrainian mobilization collapse (200,000+ AWOL), European guarantee without US, Russian mutiny if oil below $70.",
   outcome:"Most likely: extended frozen conflict. Russia gains Donbas, Ukraine retains independence and Western integration path.",
   connectedTo:[{warId:'iran-us-israel',warName:'Iran–US/Israel War',types:['political','actors'],strength:'direct',desc:'Russia provides Iran targeting intel; all US diplomatic bandwidth consumed by Iran.'},{warId:'sudan-civil-war',warName:'Sudan Civil War',types:['weapons','actors'],strength:'indirect',desc:"Wagner Group (Africa Corps) provided RSF weapons."},{warId:'myanmar-civil-war',warName:'Myanmar Civil War',types:['weapons'],strength:'indirect',desc:'Russia supplies Myanmar junta.'}],news:[]},
  {id:'israel-hamas-gaza',name:'Gaza / Israel–Hamas War',location:'Gaza Strip',startDate:'Oct 7, 2023',dayCount:519,intensity:'high',status:'Active',lat:31.5,lng:34.5,
   oneLiner:'48,000+ Palestinian deaths; IDF split across Gaza and Iran war; 100+ hostages believed alive.',
   side1Name:'Israel (IDF)',side2Name:'Hamas / PIJ',side1Score:72,
   battleAssessment:'Hamas leadership largely eliminated, tunnel network mostly destroyed. Hamas retains fighting capacity; IDF now splits resources between Gaza and Iran front.',
   casualties:[{label:'Palestinian Deaths',val:'48,000+',cls:'r'},{label:'Palestinian Wounded',val:'110,000+',cls:''},{label:'IDF KIA',val:'~800+',cls:'a'},{label:'IDF Wounded',val:'~5,000+',cls:''},{label:'Israeli Civilian KIA',val:'~1,200',cls:''},{label:'Displaced (Gaza)',val:'1.9 million',cls:''}],
   casualtyNote:"Palestinian figures from Gaza Health Ministry. Oct 7 Israeli toll: ~1,200 killed.",
   side1Adv:['Near-total air superiority','Hamas leadership largely eliminated','US arms and intelligence support','Iron Dome defense'],
   side2Adv:['Tunnel network partially intact','Hostages as leverage (100+ remaining)','International political isolation','Civilian casualty narrative undermining support'],
   recentDev:'IDF managing two-front war: Gaza and Iran. Hezbollah opening northern front in solidarity with Iran. 100+ hostages believed still alive in tunnels.',
   leaders:[{name:'Benjamin Netanyahu',title:'Israeli PM',side:'1',bio:'Managing unprecedented two-front war.'},{name:'Yoav Gallant',title:'Defense Minister',side:'1',bio:'Coordinating IDF across Gaza and Iran.'},{name:'Yahya Sinwar',title:'Hamas Leader (deceased)',side:'2',bio:'Killed by IDF October 2024; Hamas under collective leadership.'},{name:'Mohammed Deif',title:'Hamas Military Cmdr',side:'2',bio:'Believed killed July 2024.'}],
   econMetrics:[{label:'Gaza GDP',val:'~−80%',change:'Since Oct 2023',dir:'down'},{label:'Reconstruction Cost',val:'$80B+',change:'UN estimate',dir:'neutral'},{label:'Aid Blocked',val:'90%+',change:'vs pre-war',dir:'down'},{label:'Israeli Mil. Spend',val:'+40%',change:'Annual budget',dir:'up'}],
   econOverview:"Gaza faces total economic collapse. UN estimates $80B+ reconstruction cost. Israel's military spending surged 40%; Iran war adds additional fiscal strain.",
   side1Allies:[{country:'USA',role:'Primary weapons supplier'},{country:'UK',role:'Weapons (partially suspended)'},{country:'Germany',role:'Arms support (under review)'}],
   side2Allies:[{country:'Iran',role:'Strategic backer pre-2026'},{country:'Hezbollah',role:'Northern front, missiles'},{country:'Houthis',role:'Red Sea solidarity attacks'}],
   shortTerm:'IDF at reduced intensity as resources shift to Iran. Hostage deal possible if Iran ceasefire creates space.',
   mediumTerm:'Post-war Gaza governance unresolved. No Israeli exit strategy.',
   wildcards:'Hezbollah full-scale war, hostage deaths, ICJ ruling, US arms embargo.',
   outcome:'IDF achieves military victory but no political solution. Hamas degraded not eliminated.',
   connectedTo:[{warId:'iran-us-israel',warName:'Iran–US/Israel War',types:['actors','military'],strength:'direct',desc:'Hamas and Hezbollah are Iranian proxies; Israel fighting Iran directly.'},{warId:'yemen-houthis',warName:'Yemen / Houthis',types:['proxy','weapons'],strength:'direct',desc:"Houthis declared solidarity with Hamas Oct 2023."}],news:[]},
  {id:'yemen-houthis',name:'Yemen / Houthi Conflict',location:'Yemen / Red Sea',startDate:'2014 (Red Sea Oct 2023)',dayCount:null,intensity:'high',status:'Active',lat:15.5,lng:44,
   oneLiner:'Houthis continue Red Sea attacks and coordinate directly with Iran; world worst simultaneous maritime chokepoint crisis with Hormuz.',
   side1Name:'US / Coalition',side2Name:'Houthis (Ansar Allah)',side1Score:45,
   battleAssessment:"Coalition inflicts significant damage on Houthi infrastructure but cannot stop the Red Sea campaign. Iran's weapons pipeline remains intact.",
   casualties:[{label:'Houthi KIA (est)',val:'~3,000+',cls:'r'},{label:'Civilian Deaths',val:'~1,000+ (US strikes)',cls:'r'},{label:'Ships Attacked',val:'100+',cls:'a'},{label:'Yemen Total (2014+)',val:'~150,000',cls:''},{label:'Displaced',val:'4.5 million',cls:''},{label:'Famine Risk',val:'17 million',cls:'r'}],
   casualtyNote:"Yemen conflict total since 2014 ~150,000+.",
   side1Adv:['Air and naval superiority','Carrier strike group presence','Saudi border control','Coalition intelligence network'],
   side2Adv:["Iranian anti-ship missiles and drones","Red Sea narrow chokepoint geography","Domestic popular support as 'resistance'","Direct Iran coordination during Epic Fury"],
   recentDev:"Houthis escalated attacks in direct coordination with Iranian operations during Epic Fury. Combined Hormuz + Red Sea disruption: worst simultaneous maritime chokepoint crisis in decades.",
   leaders:[{name:'Abdul-Malik al-Houthi',title:'Houthi Supreme Leader',side:'2',bio:"Led Ansar Allah since 2004."},{name:'Mohammed Ali al-Houthi',title:'Supreme Revolutionary Committee',side:'2',bio:"Administrative head of Houthi government."}],
   econMetrics:[{label:'Red Sea Trade',val:'−60%',change:'Since Nov 2023',dir:'down'},{label:'Suez Canal Revenue',val:'−50%',change:'Egypt near-crisis',dir:'down'},{label:'Shipping Insurance',val:'+300%',change:'War risk premium',dir:'up'},{label:'Yemen GDP',val:'−50%',change:'vs 2014',dir:'down'}],
   econOverview:"Red Sea disruption forces ships to reroute around Cape of Good Hope adding 10–14 days per voyage. Combined with Hormuz: Egypt losing ~$800M/month in Suez revenue.",
   side1Allies:[{country:'USA',role:'Operation Prosperity Guardian'},{country:'UK',role:'Joint airstrikes on Houthi sites'},{country:'Saudi Arabia',role:'Yemen coalition, air defense'}],
   side2Allies:[{country:'Iran',role:'Weapons, training, targeting intel'},{country:'Hamas',role:'Political solidarity'},{country:'Hezbollah',role:'Axis of resistance coordination'}],
   shortTerm:'Red Sea attacks continue. Saudi Arabia seeking back-channel deal.',
   mediumTerm:'If Iran war ends, Houthi leverage decreases sharply. Saudi-Houthi settlement possible.',
   wildcards:'Houthi sinking major warship, Saudi direct negotiations, Iran pipeline cut.',
   outcome:'Red Sea attacks continue at reduced intensity as Iran war winds down. Saudi-Houthi deal eventually reached.',
   connectedTo:[{warId:'iran-us-israel',warName:'Iran–US/Israel War',types:['proxy','weapons','actors'],strength:'direct',desc:"Houthis are Iran's most active proxy, contributing to Hormuz disruption."},{warId:'israel-hamas-gaza',warName:'Gaza / Hamas War',types:['proxy','political'],strength:'direct',desc:"Houthis began Red Sea campaign in solidarity with Hamas."}],news:[]},
  {id:'sudan-civil-war',name:'Sudan Civil War',location:'Sudan, NE Africa',startDate:'Apr 15, 2023',dayCount:null,intensity:'high',status:'Active',lat:15,lng:30,
   oneLiner:"SAF vs RSF war has killed 150,000+ and displaced 9 million — the world's worst active humanitarian catastrophe.",
   side1Name:'SAF (Army)',side2Name:'RSF (Paramilitaries)',side1Score:48,
   battleAssessment:"Brutal stalemate: RSF controls Darfur and Khartoum suburbs; SAF holds Port Sudan. Both sides committing war crimes.",
   casualties:[{label:'Total Deaths',val:'150,000+',cls:'r'},{label:'Displaced',val:'9 million+',cls:''},{label:'Famine Risk',val:'25 million',cls:'r'},{label:'Refugees to Chad',val:'600,000+',cls:''},{label:'Khartoum Status',val:'Contested',cls:'a'},{label:'Aid Access',val:'<30%',cls:''}],
   casualtyNote:"UN calls this the worst active humanitarian disaster globally. 25 million face acute food insecurity.",
   side1Adv:['Air force and heavy artillery','International recognition','Controls Port Sudan supply lifeline','Egyptian diplomatic support'],
   side2Adv:['Controls Khartoum suburbs and Darfur','UAE weapons and financial support','Experienced fighters (former Janjaweed)','Gold smuggling revenue stream'],
   recentDev:"SAF receiving Iranian-supplied drones. RSF continuing ethnic cleansing in Darfur with UN reporting genocide-level atrocities. UAE-RSF gold trade confirmed by UN Panel of Experts.",
   leaders:[{name:'Gen. Abdel Fattah al-Burhan',title:'SAF Commander / De facto head of state',side:'1',bio:'Led 2021 coup; fighting for survival from Port Sudan.'},{name:"Gen. Mohamed Hamdan Dagalo",title:"RSF Commander ('Hemeti')",side:'2',bio:'Former Janjaweed leader; built RSF into 100,000+ force with UAE backing.'}],
   econMetrics:[{label:'Sudan GDP',val:'−40%',change:'Since 2023',dir:'down'},{label:'Inflation',val:'250%+',change:'Annual',dir:'up'},{label:'Aid Access',val:'<30%',change:'Of needed',dir:'down'},{label:'Gold Smuggling',val:'$Billions/yr',change:'RSF revenue',dir:'neutral'}],
   econOverview:"Sudan's economy collapsed. Gold reserves smuggled by RSF through UAE at below-market rates. WFP calls it the worst food crisis on earth.",
   side1Allies:[{country:'Egypt',role:'Military support, political backing'},{country:'Iran',role:'Drone supply (Shahed variants)'},{country:'Saudi Arabia',role:'Cautious SAF support'}],
   side2Allies:[{country:'UAE',role:'Weapons, financing, gold trade'},{country:'Libya',role:'Weapons transit routes'},{country:'Russia (Africa Corps)',role:'Legacy RSF support'}],
   shortTerm:'Stalemate continues. Famine in Darfur spreading.',
   mediumTerm:'Risk of failed state. Partition into SAF-north and RSF-west increasingly likely.',
   wildcards:'Gulf Arab mediation, Hemeti death, international intervention on genocide findings.',
   outcome:'Prolonged stalemate 2–3 more years, gradual partition.',
   connectedTo:[{warId:'ukraine-russia',warName:'Russia–Ukraine War',types:['weapons','actors'],strength:'indirect',desc:'Wagner Group (Africa Corps) provided RSF weapons.'},{warId:'iran-us-israel',warName:'Iran–US/Israel War',types:['weapons'],strength:'indirect',desc:'Iran supplying SAF with Shahed drones.'}],news:[]},
  {id:'myanmar-civil-war',name:'Myanmar Civil War',location:'Southeast Asia',startDate:'Feb 1, 2021',dayCount:null,intensity:'medium',status:'Active',lat:19,lng:96,
   oneLiner:'Junta losing ground — largest territorial shifts since coup — 3 million displaced; rare earth supply at risk.',
   side1Name:'Resistance (PDF/EAOs)',side2Name:'Military Junta (SAC)',side1Score:55,
   battleAssessment:'PDF and ethnic armed organizations have made the most significant territorial gains since 2021. Junta retains air power but lost control of large parts of the country.',
   casualties:[{label:'Total Deaths',val:'50,000+',cls:'r'},{label:'Junta KIA',val:'~20,000+',cls:''},{label:'Resistance KIA',val:'~10,000+',cls:'a'},{label:'Displaced',val:'3 million+',cls:''},{label:'Political Prisoners',val:'20,000+',cls:''}],
   casualtyNote:"Estimates unreliable due to media restrictions. Operation 1027 (Oct 2023) was a turning point.",
   side1Adv:['Growing territorial control — 60%+ contested','Popular support','Junta conscription failures, low morale'],
   side2Adv:['Air power — jets and helicopter gunships','Control of major cities and Naypyidaw','China diplomatic support (partial)'],
   recentDev:'Operation 1027 captured Laukkaing and dozens of border towns. SAC deploying conscripts — severe manpower shortage. China brokering negotiations to protect BRI investments.',
   leaders:[{name:'Min Aung Hlaing',title:'Junta Chief (SAC Chairman)',side:'2',bio:'Led Feb 2021 coup; under ICC arrest warrant.'},{name:'Aung San Suu Kyi',title:'NLD Leader (imprisoned)',side:'1',bio:'Sentenced to 27 years; symbol of resistance.'}],
   econMetrics:[{label:'Myanmar GDP',val:'−18%',change:'Since coup',dir:'down'},{label:'Kyat Value',val:'−60%+',change:'vs USD',dir:'down'},{label:'FDI',val:'−80%',change:'vs pre-coup',dir:'down'},{label:'Rare Earth Risk',val:'HIGH',change:'Heavy RE disrupted',dir:'down'}],
   econOverview:"Myanmar produces significant heavy rare earths (dysprosium, terbium) critical for EV motors and wind turbines. Junta instability creates supply chain risk for green energy transition.",
   side1Allies:[{country:'Western diaspora',role:'Financial support'},{country:'Thailand',role:'Porous border, some transit'}],
   side2Allies:[{country:'China',role:'Diplomatic shield, BRI interests'},{country:'Russia',role:'Weapons supplier (jets, drones)'},{country:'India',role:'Border trade maintained'}],
   shortTerm:'Resistance continues territorial expansion. Junta airstrikes intensify.',
   mediumTerm:'Junta retains cities, resistance controls countryside — de facto partition.',
   wildcards:'China cutting junta support, mass defections, resistance capture of Mandalay.',
   outcome:'Prolonged fragmented conflict. Myanmar de facto splits: urban junta vs rural resistance.',
   connectedTo:[{warId:'ukraine-russia',warName:'Russia–Ukraine War',types:['weapons'],strength:'indirect',desc:'Russia supplies Myanmar junta with fighter jets and drones.'}],news:[]},
  {id:'drc-m23',name:'DRC / Eastern Congo War',location:'Eastern DRC, Central Africa',startDate:'Nov 2021 (M23 resurgence)',dayCount:null,intensity:'high',status:'Active',lat:-4,lng:29,
   oneLiner:'M23 captured Goma in January 2026 — ~70% of global cobalt supply and critical coltan chains under threat.',
   side1Name:'FARDC / SADC Forces',side2Name:'M23 / Rwanda (RDF)',side1Score:30,
   battleAssessment:'M23 — backed by Rwandan Defence Forces — captured Goma in January 2026. FARDC routed in the east. Global cobalt and coltan supply at risk.',
   casualties:[{label:'Deaths (since 2021)',val:'7,000+',cls:'r'},{label:'Displaced',val:'7 million',cls:''},{label:'After Goma Fall',val:'300+ killed',cls:'r'},{label:'FARDC Status',val:'Routed east',cls:'a'},{label:'Cobalt Supply',val:'AT RISK',cls:'r'}],
   casualtyNote:"Goma fell January 27, 2026. UN estimates 7 million displaced in eastern DRC.",
   side1Adv:['International recognition and SADC support','Southern African forces deployed','UN MONUSCO presence (limited)'],
   side2Adv:['Rwandan military backing (RDF in-country)','Captured Goma and key eastern territory','Control of cobalt / coltan / gold mineral chains'],
   recentDev:'M23 captured Goma January 27, 2026. Rwanda denies RDF presence despite US and UN documentation. DRC accounts for ~70% of global cobalt — EV supply chains directly exposed.',
   leaders:[{name:'Félix Tshisekedi',title:'DRC President',side:'1',bio:'Seeking international intervention; accused Rwanda of invasion at UN.'},{name:'Paul Kagame',title:'Rwandan President',side:'2',bio:"Denies Rwanda's involvement despite documented RDF presence."},{name:'Bertrand Bisimwa',title:'M23 Political Leader',side:'2',bio:'Demands DRC federal restructuring.'}],
   econMetrics:[{label:'Global Cobalt',val:'~70% at risk',change:'DRC source',dir:'down'},{label:'Coltan Supply',val:'Disrupted',change:'30%+ global',dir:'down'},{label:'Gold Smuggling',val:'$1B+/yr',change:'M23 controlled',dir:'neutral'},{label:'EV Supply Chain',val:'Exposed',change:'CATL, Panasonic',dir:'down'}],
   econOverview:'Eastern DRC contains vast cobalt, coltan, and gold reserves. M23 and Rwanda capturing mineral wealth. Global EV and tech supply chains have direct coltan and cobalt exposure to this conflict.',
   side1Allies:[{country:'SADC (South Africa, Mozambique)',role:'Military deployment, casualties'},{country:'UN MONUSCO',role:'Peacekeeping (limited)'},{country:'Angola',role:'Mediation'}],
   side2Allies:[{country:'Rwanda',role:'Direct military intervention (officially denied)'},{country:'Uganda',role:'Opportunistic — own interests in north'}],
   shortTerm:'M23 consolidating Goma. FARDC attempting counteroffensive.',
   mediumTerm:'Risk of formal Rwanda-DRC war. Minerals negotiation possible if pressure mounts.',
   wildcards:'Formal Rwanda-DRC war declaration, US sanctions on Rwanda, ICC indictments.',
   outcome:'M23 retains eastern DRC de facto control. DRC sovereignty permanently compromised in east.',
   connectedTo:[{warId:'sudan-civil-war',warName:'Sudan Civil War',types:['economic','actors'],strength:'indirect',desc:'Both involve Gulf states competing for African mineral wealth.'},{warId:'somalia-alshabaab',warName:'Somalia / Al-Shabaab',types:['actors'],strength:'indirect',desc:'Both rely on AU peacekeeping from the same troop contributors.'}],news:[]},
  {id:'somalia-alshabaab',name:'Somalia / Al-Shabaab',location:'Somalia / East Africa',startDate:'2006 (ongoing)',dayCount:null,intensity:'medium',status:'Active',lat:5,lng:46,
   oneLiner:"Al-Shabaab controls ~20% of Somalia; piracy resurging as Red Sea conflict diverts naval resources.",
   side1Name:'Federal Gov / AUSSOM',side2Name:'Al-Shabaab (ASB)',side1Score:52,
   battleAssessment:"Federal Government and AU mission retook key cities but al-Shabaab retains significant rural areas. ASB's $100M+ annual tax revenue makes it financially resilient.",
   casualties:[{label:'Annual Deaths',val:'~4,000–6,000',cls:'r'},{label:'ASB Fighters',val:'~7–12,000',cls:''},{label:'Displaced',val:'3.8 million',cls:''},{label:'Conflict Total (2006+)',val:'500,000+',cls:'r'},{label:'Piracy Incidents',val:'Rising 2025–26',cls:'a'}],
   casualtyNote:"Conflict total since 2006 ~500,000+ including famine deaths. Piracy resurging as Houthi threat diverts Indian Ocean naval resources.",
   side1Adv:['US AFRICOM drone/airstrike support','AU mission AUSSOM','Growing Somali National Army capacity'],
   side2Adv:['Rural population control and $100M+/yr taxation','Ideological cohesion','Cross-border Kenya and Ethiopia operations'],
   recentDev:"Hassan Sheikh's 'Total War' campaign stalled — SNA lacks capacity to hold liberated territory. AU troop drawdown creating security gaps. Piracy incidents increasing in Indian Ocean as Houthi situation diverts naval assets.",
   leaders:[{name:'Hassan Sheikh Mohamud',title:'Somali President',side:'1',bio:"Launched 'Total War'; struggling to build SNA capacity."},{name:'Ahmed Diriye (Abiy)',title:'Al-Shabaab Emir',side:'2',bio:'Led al-Shabaab since 2014; maintained cohesion.'}],
   econMetrics:[{label:'Somalia GDP/capita',val:'~$450',change:"One of world's lowest",dir:'neutral'},{label:'ASB Tax Revenue',val:'$100M+/yr',change:'From controlled areas',dir:'neutral'},{label:'Aid Dependency',val:'60%+',change:'Of federal budget',dir:'neutral'},{label:'Piracy Risk',val:'Rising',change:'Indian Ocean',dir:'up'}],
   econOverview:'Somalia matters primarily for Indian Ocean shipping security. Al-Shabaab piracy risk compounding Houthi Red Sea disruption. Federal government depends on aid for 60%+ of budget.',
   side1Allies:[{country:'USA (AFRICOM)',role:'Airstrikes, special forces advising'},{country:'African Union (AUSSOM)',role:'Ethiopia, Uganda, Kenya, Djibouti'},{country:'Turkey',role:'Military training, Mogadishu base'},{country:'UAE',role:'Financial and security support'}],
   side2Allies:[{country:'Al-Qaeda',role:'Ideological affiliation'},{country:'Local clan networks',role:'Protection and recruitment'}],
   shortTerm:'Continued stalemate. AU troop drawdown creates security gaps.',
   mediumTerm:'Political reconciliation with clan leaders more likely to reduce ASB than military pressure.',
   wildcards:'Ethiopian withdrawal from AUSSOM, major ASB attack in Nairobi, climate famine.',
   outcome:"Prolonged low-intensity conflict. 'Frozen insurgency' for 5–10 more years.",
   connectedTo:[{warId:'drc-m23',warName:'DRC / Congo War',types:['actors'],strength:'indirect',desc:'Both rely on AU peacekeeping from the same pool of troop contributors.'},{warId:'yemen-houthis',warName:'Yemen / Houthis',types:['economic'],strength:'indirect',desc:"Red Sea disruption raises East African food import costs."}],news:[]},
];



// ── State ──
const S={
  wars:WARS.map(w=>({...w})),
  activeWar:0,showConns:false,detailTab:'overview',
  refreshing:false,refreshMsg:'',showAddModal:false,addForm:null,
  error:null,success:null,lastRefresh:null,
  theme:localStorage.getItem('gww_theme')||'dark',
  markets:[],mktStatus:'idle',warRisk:{},warTradingNote:{},refreshLog:[],
};
document.documentElement.setAttribute('data-theme',S.theme);

// ── Scenario history ── persisted in localStorage ──
const SCEN_HIST_KEY='gww_scen_hist';
function loadScenHist(){try{return JSON.parse(localStorage.getItem(SCEN_HIST_KEY)||'{}')}catch{return{}}}
function saveScenHist(hist){try{localStorage.setItem(SCEN_HIST_KEY,JSON.stringify(hist))}catch{}}
let SCEN_HIST=loadScenHist();

function snapshotScenarios(){
  const hist=loadScenHist();
  const ts=Date.now();
  S.wars.forEach(w=>{
    const td=TRADING[w.id];
    if(!td||!td.scenarios||!td.scenarios.length)return;
    if(!hist[w.id])hist[w.id]=[];
    const probs={};
    td.scenarios.forEach(sc=>{
      const n=parseInt((sc.prob||'0').replace('%',''))||0;
      probs[sc.name]=n;
    });
    const last=hist[w.id][hist[w.id].length-1];
    const same=last&&JSON.stringify(last.p)===JSON.stringify(probs);
    if(!same)hist[w.id].push({ts,p:probs});
    if(hist[w.id].length>40)hist[w.id]=hist[w.id].slice(-40);
  });
  SCEN_HIST=hist;
  saveScenHist(hist);
}

function renderScenSparkline(points, color, w=120, h=28){
  if(!points||points.length<2)return`<svg width="${w}" height="${h}"><text x="4" y="16" font-size="9" fill="var(--muted)" font-family="monospace">no history</text></svg>`;
  const mx=Math.max(...points,1), mn=Math.min(...points);
  const range=mx-mn||1;
  const pad=3, iw=w-pad*2, ih=h-pad*2;
  const xs=points.map((_,i)=>pad+i*(iw/(points.length-1)));
  const ys=points.map(v=>pad+ih-(((v-mn)/range)*ih));
  const d='M'+xs.map((x,i)=>`${x.toFixed(1)},${ys[i].toFixed(1)}`).join('L');
  // fill area
  const fa=`M${xs[0].toFixed(1)},${(h-pad)}L`+xs.map((x,i)=>`${x.toFixed(1)},${ys[i].toFixed(1)}`).join('L')+`L${xs[xs.length-1].toFixed(1)},${h-pad}Z`;
  return`<svg width="${w}" height="${h}" style="overflow:visible"><defs><linearGradient id="sg${color.replace(/[^a-z]/gi,'')}" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="${color}" stop-opacity=".25"/><stop offset="100%" stop-color="${color}" stop-opacity="0"/></linearGradient></defs><path d="${fa}" fill="url(#sg${color.replace(/[^a-z]/gi,'')})" /><path d="${d}" fill="none" stroke="${color}" stroke-width="1.5" stroke-linejoin="round"/><circle cx="${xs[xs.length-1].toFixed(1)}" cy="${ys[ys.length-1].toFixed(1)}" r="2.5" fill="${color}"/></svg>`;
}

function renderScenHistory(warId){
  const hist=SCEN_HIST[warId];
  const td=TRADING[warId];
  if(!td||!td.scenarios||!td.scenarios.length)return'';
  if(!hist||hist.length<2)return`<div class="scen-hist"><div class="scen-hist-title">📈 Probability History</div><div style="font-family:'Courier New',monospace;font-size:10px;color:var(--muted)">Tracking starts after 2+ refreshes — check back soon.</div></div>`;
  const colors=['var(--green)','var(--amber)','var(--red)','var(--blue)'];
  const rows=td.scenarios.map((sc,i)=>{
    const pts=hist.map(h=>h.p[sc.name]||0);
    const cur=pts[pts.length-1];
    const prev=pts.length>1?pts[pts.length-2]:cur;
    const delta=cur-prev;
    const deltaStr=delta===0?'—':delta>0?`+${delta}%`:`${delta}%`;
    const deltaCls=delta>0?'delta-up':delta<0?'delta-dn':'delta-flat';
    const col=colors[i%colors.length];
    return`<div class="scen-hist-row">
      <div class="scen-hist-lbl">${sc.name}</div>
      <div class="scen-hist-spark">${renderScenSparkline(pts,col,120,28)}</div>
      <div class="scen-hist-cur" style="color:${col}">${cur}%</div>
      <div class="scen-hist-delta ${deltaCls}">${deltaStr}</div>
    </div>`;
  }).join('');
  const firstTs=new Date(hist[0].ts).toLocaleDateString('en-US',{month:'short',day:'numeric'});
  const lastTs=new Date(hist[hist.length-1].ts).toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit'});
  return`<div class="scen-hist"><div class="scen-hist-title">📈 Probability History <span style="color:var(--muted);font-weight:400">(${hist.length} snapshots · ${firstTs}→${lastTs})</span></div><div class="scen-hist-rows">${rows}</div></div>`;
}

// ── Source transparency ── track which outlets cover each war ──
function buildSourceLog(warId){
  const news=(S.wars.find(w=>w.id===warId)||{}).news||[];
  if(!news.length)return null;
  const map={};
  news.forEach(a=>{
    if(!a.source)return;
    const k=a.source.trim();
    if(!map[k])map[k]={count:0,tier:a.tier||'m'};
    map[k].count++;
  });
  return Object.entries(map).sort((a,b)=>b[1].count-a[1].count).map(([name,v])=>({name,count:v.count,tier:v.tier}));
}

function renderSourcePanel(warId){
  const sources=buildSourceLog(warId);
  if(!sources||!sources.length)return'';
  const total=sources.reduce((s,x)=>s+x.count,0);
  const highCount=sources.filter(s=>s.tier==='h').reduce((s,x)=>s+x.count,0);
  const stateCount=sources.filter(s=>s.tier==='s').reduce((s,x)=>s+x.count,0);
  const confPct=total?Math.round(((highCount*2+(total-stateCount))/((total*2)||1))*100):0;
  const confLbl=confPct>=75?'HIGH':confPct>=50?'MEDIUM':'LOW';
  const confCls=confPct>=75?'conf-h':confPct>=50?'conf-m':'conf-l';
  const rows=sources.slice(0,6).map(s=>{
    const pct=Math.round((s.count/total)*100);
    const tc={h:'sh',m:'sm',l:'sl',s:'ss'}[s.tier]||'sm';
    return`<div class="src-row">
      <div class="src ${tc}" style="flex-shrink:0">${s.tier==='h'?'✓':s.tier==='s'?'⚠':''}${s.tier.toUpperCase()}</div>
      <div class="src-name">${s.name}</div>
      <div class="src-bar-wrap"><div class="src-bar ${tc}" style="width:${pct}%"></div></div>
      <div class="src-count">${s.count}</div>
    </div>`;
  }).join('');
  return`<div class="src-panel">
    <div class="src-panel-title">Source Breakdown <span class="conf-badge ${confCls}" style="margin-left:auto">${confLbl} CONFIDENCE</span></div>
    ${rows}
    <div style="font-family:'Courier New',monospace;font-size:9px;color:var(--muted);margin-top:7px">${total} articles · ${sources.length} outlets · last pull ${S.lastRefresh?S.lastRefresh.toLocaleTimeString():'—'}</div>
  </div>`;
}

// ── Custom wars — add/remove persisted to localStorage ──
const CUSTOM_WARS_KEY='gww_custom_wars';
function loadCustomWars(){try{return JSON.parse(localStorage.getItem(CUSTOM_WARS_KEY)||'[]')}catch{return[]}}
function saveCustomWars(){
  const customs=S.wars.filter(w=>w.custom);
  try{localStorage.setItem(CUSTOM_WARS_KEY,JSON.stringify(customs))}catch{}
}

// ── Known countries for entity extraction ──
const KNOWN_COUNTRIES=['Afghanistan','Albania','Algeria','Angola','Armenia','Australia','Austria','Azerbaijan','Bahrain','Bangladesh','Belarus','Belgium','Bolivia','Brazil','Bulgaria','Cambodia','Cameroon','Canada','Chile','China','Colombia','Croatia','Cuba','Czech','Denmark','Ecuador','Egypt','Ethiopia','Finland','France','Georgia','Germany','Ghana','Greece','Guatemala','Haiti','Hungary','India','Indonesia','Iran','Iraq','Ireland','Israel','Italy','Japan','Jordan','Kazakhstan','Kenya','Kuwait','Lebanon','Libya','Malaysia','Mali','Mexico','Moldova','Morocco','Myanmar','Netherlands','Niger','Nigeria','North Korea','Norway','Pakistan','Palestine','Panama','Peru','Philippines','Poland','Portugal','Qatar','Romania','Russia','Rwanda','Saudi Arabia','Senegal','Serbia','Somalia','South Korea','South Sudan','Spain','Sudan','Sweden','Switzerland','Syria','Taiwan','Thailand','Tunisia','Turkey','UAE','Uganda','UK','Ukraine','United States','USA','Venezuela','Vietnam','Yemen','Zimbabwe'];

// ── Fetch Wikipedia summary ──
async function fetchWikiSummary(query){
  // Try direct article lookup first, then search
  const clean=query.replace(/\s+/g,' ').trim();
  const attempts=[
    `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(clean)}`,
    // Also try searching if direct lookup misses
  ];
  for(const url of attempts){
    try{
      const r=await fetch(url,{signal:AbortSignal.timeout(6000)});
      if(!r.ok)continue;
      const d=await r.json();
      if(d.extract&&d.extract.length>100)return d;
    }catch(e){}
  }
  // Try Wikipedia search API as fallback
  try{
    const sr=await fetch(`https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(clean)}&format=json&origin=*&srlimit=3`,{signal:AbortSignal.timeout(6000)});
    if(sr.ok){
      const sd=await sr.json();
      const top=(sd?.query?.search||[])[0];
      if(top){
        const r2=await fetch(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(top.title)}`,{signal:AbortSignal.timeout(6000)});
        if(r2.ok){const d2=await r2.json();if(d2.extract)return d2;}
      }
    }
  }catch(e){}
  return null;
}

// ── Extract person names from text (2+ capitalised words, not country names) ──
function extractNames(text){
  if(!text)return[];
  const skip=new Set([...KNOWN_COUNTRIES,'United','States','North','South','East','West','Prime','Minister','President','General','Colonel','Secretary','Defense','Foreign','Affairs','National','Security','Council','Forces','Army','Navy','Air','Force','Government','Ministry','Ministry','Islamic','Republic','Democratic','People','Federal','State','New','War','Civil','Military','Armed','International','United','Nations','NATO','European','Union']);
  const matches=text.match(/\b([A-Z][a-z]{1,14})\s+([A-Z][a-z]{1,14})(?:\s+([A-Z][a-z]{1,14}))?\b/g)||[];
  const freq={};
  matches.forEach(m=>{
    const parts=m.split(' ');
    if(parts.every(p=>!skip.has(p)&&p.length>1)){
      freq[m]=(freq[m]||0)+1;
    }
  });
  return Object.entries(freq).sort((a,b)=>b[1]-a[1]).slice(0,6).map(e=>e[0]);
}

// ── Extract country names from text ──
function extractCountries(text){
  if(!text)return[];
  const found=[];
  KNOWN_COUNTRIES.forEach(c=>{if(text.includes(c)&&!found.includes(c))found.push(c);});
  return found;
}

// ── Infer leader title from context ──
function inferTitle(name,text,side){
  const t=text||'';
  const titlePatterns=[
    [/President\s+\w+/,'President'],[/Prime Minister\s+\w+/,'Prime Minister'],
    [/General\s+\w+/,'General'],[/Minister\s+\w+/,'Minister'],
    [/Chairman\s+\w+/,'Chairman'],[/Commander\s+\w+/,'Commander'],
    [/Emir\s+\w+/,'Emir'],[/King\s+\w+/,'King'],[/Sheikh\s+\w+/,'Sheikh'],
  ];
  for(const[re,title]of titlePatterns){
    if(re.test(t)&&t.includes(name.split(' ').slice(-1)[0]))return title;
  }
  return side==='1'?'Government Leader / Commander':'Opposing Leader / Commander';
}

// ── Enrich a custom war with Wikipedia + news data ──
async function enrichWarFromSources(war, newsItems){
  const allText=[
    war.name, war._query||'',
    ...(newsItems||[]).map(n=>n.title||''),
  ].join(' ');

  // 1. Fetch Wikipedia
  const wikiTerms=[war.name, war._query, `${war.side1Name} ${war.side2Name} war`];
  let wiki=null;
  for(const term of wikiTerms){
    if(!term)continue;
    wiki=await fetchWikiSummary(term);
    if(wiki)break;
  }
  const wikiText=wiki?.extract||'';
  const fullText=allText+' '+wikiText;

  // 2. Extract entities
  const names=extractNames(fullText);
  const countries=extractCountries(fullText);

  // 3. Assign leaders (first 2-3 names to sides, context-based)
  const s1Lower=war.side1Name.toLowerCase();
  const s2Lower=war.side2Name.toLowerCase();

  // Split countries into two camps by proximity to side names in text
  const s1Countries=countries.filter(c=>{
    const idx=fullText.indexOf(c);
    const ctx=fullText.slice(Math.max(0,idx-80),idx+80).toLowerCase();
    return ctx.includes(s1Lower.split(/\W/)[0])||ctx.includes('government')||ctx.includes('official');
  }).slice(0,3);
  const s2Countries=countries.filter(c=>!s1Countries.includes(c)).slice(0,3);

  // Build leaders array — assign first half of names to s1, rest to s2
  const leaders=[];
  names.slice(0,4).forEach((n,i)=>{
    const side=i<Math.ceil(names.length/2)?'1':'2';
    const bio=wikiText.includes(n)?
      wikiText.split('.').find(s=>s.includes(n.split(' ').slice(-1)[0]))?.trim()||`Key figure in ${war.name}.`
      :`Named in news coverage of ${war.name}.`;
    leaders.push({name:n,title:inferTitle(n,wikiText,side),side,bio:bio.slice(0,180)});
  });
  // Always ensure at least one per side
  if(!leaders.find(l=>l.side==='1'))leaders.unshift({name:war.side1Name+' Leader',title:'Government Leader',side:'1',bio:`Head of ${war.side1Name}. Refresh for verified identity from news.`});
  if(!leaders.find(l=>l.side==='2'))leaders.push({name:war.side2Name+' Leader',title:'Opposition Leader',side:'2',bio:`Head of ${war.side2Name}. Refresh for verified identity from news.`});

  // 4. Alliances
  const s1Allies=s1Countries.length?
    s1Countries.map(c=>({country:c,role:'Ally / supporter — sourced from news'})):
    [{country:'International backers',role:'Monitoring — refresh to update'}];
  const s2Allies=s2Countries.length?
    s2Countries.map(c=>({country:c,role:'Ally / supporter — sourced from news'})):
    [{country:'External supporters',role:'Monitoring — refresh to update'}];

  // 5. Military advantages from wiki/news text
  const s1Adv=[], s2Adv=[];
  const advKeywords={
    air:['air force','air power','jets','drones','aircraft'],
    naval:['navy','naval','fleet','warship'],
    ground:['army','ground forces','troops','infantry','tanks'],
    missile:['missile','rockets','artillery'],
    intel:['intelligence','surveillance','reconnaissance'],
    support:['support','backed','alliance','NATO','coalition'],
  };
  Object.entries(advKeywords).forEach(([k,kws])=>{
    const inText=kws.some(kw=>fullText.toLowerCase().includes(kw));
    if(!inText)return;
    const snippet=kws.find(kw=>fullText.toLowerCase().includes(kw));
    // Assign to the side mentioned closer to it
    const idx=fullText.toLowerCase().indexOf(snippet);
    const ctx=fullText.slice(Math.max(0,idx-120),idx+120).toLowerCase();
    const side=ctx.includes(s1Lower.split(/\W/)[0])?'1':'2';
    const label={air:'Air superiority capability',naval:'Naval presence',ground:'Ground forces strength',missile:'Missile / artillery capability',intel:'Intelligence advantage',support:'External military support'}[k];
    (side==='1'?s1Adv:s2Adv).push(label+' (sourced from news/Wikipedia)');
  });
  if(!s1Adv.length)s1Adv.push(`${war.side1Name} operational capabilities — refresh to detail`);
  if(!s2Adv.length)s2Adv.push(`${war.side2Name} operational capabilities — refresh to detail`);

  // 6. EconMetrics from country mentions
  const econMetrics=[
    {label:'Regional GDP Risk',val:'Elevated',change:'Conflict premium',dir:'down'},
    {label:'FDI Flow',val:'Disrupted',change:'Capital flight risk',dir:'down'},
  ];
  if(countries.includes('Russia')||countries.includes('Iran')||countries.includes('Saudi Arabia')||countries.includes('Iraq'))
    econMetrics.push({label:'Energy Exposure',val:'HIGH',change:'Supply chain at risk',dir:'down'});
  if(countries.some(c=>['Ukraine','Russia'].includes(c)))
    econMetrics.push({label:'Wheat / Grain Risk',val:'Elevated',change:'Black Sea corridor',dir:'down'});
  if(countries.some(c=>['China','Taiwan'].includes(c)))
    econMetrics.push({label:'Semiconductor Risk',val:'CRITICAL',change:'Global supply chain',dir:'down'});
  if(countries.some(c=>['DRC','Congo','Myanmar'].includes(c)))
    econMetrics.push({label:'Rare Earth / Minerals',val:'Exposed',change:'Supply disruption',dir:'down'});
  econMetrics.push({label:'Humanitarian Cost',val:'Rising',change:'Aid + displacement',dir:'down'});

  // 7. Tactical score drift from headline sentiment
  const winWords=['advances','captures','seized','surrounds','offensive','breakthrough','gains','controls','victory','liberated','destroyed','routed','retreating','collapsed'];
  const loseWords=['retreats','withdraws','loses','falls back','encircled','casualties','massacre','defeat','surrendered','besieged','shelled','bombed'];
  let s1Score=war.side1Score||50;
  const headlineText=(newsItems||[]).map(n=>n.title||'').join(' ').toLowerCase();
  const s1Key=s1Lower.split(/[\s\/]/)[0]; // first word of side1 name
  const s2Key=s2Lower.split(/[\s\/]/)[0];
  let delta=0;
  winWords.forEach(w=>{
    const re=new RegExp(`${s1Key}[^.]{0,60}${w}|${w}[^.]{0,60}${s1Key}`,'gi');
    const re2=new RegExp(`${s2Key}[^.]{0,60}${w}|${w}[^.]{0,60}${s2Key}`,'gi');
    delta+=(headlineText.match(re)||[]).length*2;
    delta-=(headlineText.match(re2)||[]).length*2;
  });
  loseWords.forEach(w=>{
    const re=new RegExp(`${s1Key}[^.]{0,60}${w}|${w}[^.]{0,60}${s1Key}`,'gi');
    const re2=new RegExp(`${s2Key}[^.]{0,60}${w}|${w}[^.]{0,60}${s2Key}`,'gi');
    delta-=(headlineText.match(re)||[]).length*2;
    delta+=(headlineText.match(re2)||[]).length*2;
  });
  // Dampen: each refresh nudges max ±8, mean-reverts toward 50 slightly
  const nudge=Math.max(-8,Math.min(8,delta));
  const meanRevert=(s1Score-50)*0.05; // gentle pull back toward 50 if no signal
  s1Score=Math.round(Math.max(10,Math.min(90,s1Score+nudge-meanRevert)));
  war.side1Score=s1Score;

  // 8. Auto-detect connections to other wars
  const WAR_FINGERPRINTS=[
    {id:'iran-us-israel',   terms:['iran','irgc','hezbollah','hormuz','israel','mossad','epic fury']},
    {id:'ukraine-russia',   terms:['ukraine','russia','zelensky','putin','kharkiv','bakhmut','nato expansion']},
    {id:'israel-hamas-gaza',terms:['hamas','gaza','netanyahu','idf','west bank','rafah','hezbollah']},
    {id:'yemen-houthis',    terms:['houthi','yemen','red sea','ansar allah','aden','suez']},
    {id:'sudan-civil-war',  terms:['sudan','rsf','saf','khartoum','darfur','hemeti','wagner africa']},
    {id:'myanmar-civil-war',terms:['myanmar','burma','junta','sac','min aung hlaing','shan','kachin']},
    {id:'drc-m23',          terms:['drc','congo','m23','goma','rwanda','cobalt','coltan','fardc']},
    {id:'somalia-alshabaab',terms:['somalia','al-shabaab','shabaab','mogadishu','aussom','east africa']},
  ];
  const ftLower=fullText.toLowerCase();
  const newConns=[];
  WAR_FINGERPRINTS.forEach(fp=>{
    if(fp.id===war.id)return;
    const hits=fp.terms.filter(t=>ftLower.includes(t));
    if(hits.length<2)return; // need at least 2 term matches to infer a link
    const existing=(war.connectedTo||[]).find(c=>c.warId===fp.id);
    if(existing)return;
    const otherWar=S.wars.find(w=>w.id===fp.id);
    if(!otherWar)return;
    // Infer connection type from overlapping terms
    const types=[];
    if(hits.some(h=>['wagner africa','rsf','hezbollah','houthi','irgc'].includes(h)))types.push('actors');
    if(hits.some(h=>['weapons','arms','drones','missiles'].some(w=>h.includes(w))))types.push('weapons');
    if(hits.some(h=>['oil','cobalt','coltan','grain','suez','hormuz','red sea'].some(w=>h.includes(w))))types.push('economic');
    if(!types.length)types.push('political');
    newConns.push({
      warId:fp.id,
      warName:otherWar.name,
      types,
      strength: hits.length>=4?'direct':'indirect',
      desc:`${war.name} linked to ${otherWar.name} — shared references to: ${hits.slice(0,3).join(', ')}. Detected from Wikipedia/news.`,
    });
  });
  if(newConns.length){
    war.connectedTo=[...(war.connectedTo||[]),...newConns];
  }

  // 9. Patch the war object
  if(leaders.length)war.leaders=leaders;
  if(s1Adv.length>1||s2Adv.length>1){war.side1Adv=s1Adv;war.side2Adv=s2Adv;}
  war.side1Allies=s1Allies;war.side2Allies=s2Allies;
  war.econMetrics=econMetrics;
  if(wikiText){
    war.recentDev=wikiText.split('. ').slice(0,3).join('. ')+'.';
    war.oneLiner=wikiText.split('.')[0]+'.';
    war.battleAssessment=`${wikiText.split('. ').slice(1,3).join('. ')}. Tactical score: ${s1Score}% ${war.side1Name} / ${100-s1Score}% ${war.side2Name} — updating from headlines.`;
    war.econOverview=`${war.name} economic context sourced from Wikipedia and news. ${wikiText.split('. ').find(s=>s.toLowerCase().match(/econom|gdp|sanction|oil|trade|export|import/))||'Refresh for updated economic intelligence.'}`;
  }
  if(wiki?.title)war._wikiTitle=wiki.title;
  saveCustomWars();
  render();
}

function makeWarShell(name,location,side1,side2,query,id){
  const s1=side1||'Side 1', s2=side2||'Side 2';
  const loc=location||'Unknown region';
  const today=new Date().toLocaleDateString('en-US',{year:'numeric',month:'long',day:'numeric'});

  // ── TRADING ──
  TRADING[id]={
    risk:45,
    note:`${name}: Initial risk assessment at 45/100. Refresh to pull live news and recalibrate based on current developments. Monitor regional commodity exposure and safe-haven flows.`,
    signals:[
      {dir:'long',  asset:'Gold / Safe Havens',   tickers:['GC=F','GLD','IAU','SLV'], reason:`New conflict in ${loc} adds geopolitical risk premium. Gold typically bids on any escalation. Watch for breakout above recent highs.`},
      {dir:'watch', asset:'Defense & Aerospace',   tickers:['ITA','LMT','RTX','NOC','GD'], reason:`${s1} vs ${s2} conflict likely increases regional defense procurement. Monitor US/EU arms export authorizations.`},
      {dir:'watch', asset:'Regional Equities',     tickers:['EEM','VWO','^GSPC'],       reason:`Assess regional index exposure to ${loc}. Volatility elevated until conflict trajectory clear.`},
      {dir:'watch', asset:'Energy / Commodities',  tickers:['BZ=F','CL=F','NG=F','USO'],reason:`Evaluate ${loc} proximity to energy supply chains. Refresh for live market impact assessment.`},
      {dir:'short', asset:'Risk-On / High-Beta',   tickers:['QQQ','ARKK','XLY'],        reason:`New conflict zones suppress risk appetite. High-beta assets underperform during uncertainty spikes.`},
    ],
    scenarios:[
      {name:'Negotiated Settlement',  prob:'25%', cls:'sp-b', mkt:'Risk-on relief rally. Regional equities +3–6%. Safe havens ease. Defense stocks pullback.'},
      {name:'Prolonged Stalemate',    prob:'50%', cls:'sp-s', mkt:'Elevated volatility persists. Gold holds bid. Defense stays strong. Regional FX pressured.'},
      {name:'Major Escalation',       prob:'25%', cls:'sp-e', mkt:'Full risk-off. Gold +5–10%. VIX spike. Regional equities −10%+. Commodity disruption.'},
    ],
    sanctions:[
      {target:`${s2} (pending assessment)`, by:'International community', status:'par'},
    ],
  };

  // ── RUMORS ──
  if(!RUMORS[id]) RUMORS[id]=[
    {s:'unconfirmed', c:`${s1} reported mobilizing additional forces near ${loc}. Casualty figures unverified.`, src:'Social media / regional outlets', d:today},
    {s:'unconfirmed', c:`Third-party mediation talks reportedly being explored — no official confirmation from either ${s1} or ${s2}.`, src:'Diplomatic channels', d:today},
  ];

  // ── WAR OBJECT ──
  return{
    id, name, location:loc, startDate:'2025–present', dayCount:null,
    intensity:'medium', status:'Active', custom:true,
    oneLiner:`${s1} vs ${s2} in ${loc} — live news tracking active. Refresh to populate intelligence.`,
    side1Name:s1, side2Name:s2, side1Score:50,
    battleAssessment:`${s1} and ${s2} are engaged in active conflict in ${loc}. Tactical balance is currently assessed at parity (50/50) pending live news analysis. Refresh to update with latest battlefield intelligence.`,
    casualties:[
      {label:'Status',          val:'Active',       cls:'r'},
      {label:'Tracking',        val:'Google News',  cls:'a'},
      {label:'Intensity',       val:'Medium',       cls:'a'},
      {label:'Data Quality',    val:'Limited',      cls:''},
      {label:'Est. Displaced',  val:'Unknown',      cls:''},
      {label:'Int\'l Response', val:'Monitoring',   cls:''},
    ],
    casualtyNote:`Casualty data for ${name} is being sourced from Google News. Figures will update automatically on refresh. Treat early estimates with caution — casualty reporting in active conflicts is routinely under- or over-stated.`,
    side1Adv:[
      `Territorial or positional advantage in ${loc} — assessing via live news`,
      'Popular support and legitimacy narrative (pending news verification)',
      'Supply lines and logistics — monitoring for updates',
      'International recognition and diplomatic standing',
    ],
    side2Adv:[
      `Military capability and firepower in ${loc} — monitoring`,
      'Strategic depth and resource access — pending assessment',
      'Alliance support and external backing — checking sources',
      'Asymmetric tactics and adaptability — tracking reports',
    ],
    recentDev:`${name} broke out in ${loc}, pitting ${s1} against ${s2}. Conflict dynamics are being tracked via live Google News feeds. Refresh to load the latest developments, casualty reports, and tactical assessments from credible news outlets.`,
    leaders:[
      {name:`${s1} Leadership`, title:'Commander / Head of State', side:'1', bio:`Key decision-maker for ${s1}. Refresh to load verified leadership intelligence from news sources.`},
      {name:`${s2} Leadership`, title:'Commander / Head of State', side:'2', bio:`Key decision-maker for ${s2}. Refresh to load verified leadership intelligence from news sources.`},
    ],
    econMetrics:[
      {label:'Regional GDP Risk',   val:'Elevated',   change:'Conflict premium',   dir:'down'},
      {label:'FDI Flow',            val:'Disrupted',  change:'Capital flight risk', dir:'down'},
      {label:'Commodity Exposure',  val:'Monitoring', change:`${loc} supply chains`, dir:'neutral'},
      {label:'Humanitarian Cost',   val:'Rising',     change:'Displacement + aid',  dir:'down'},
      {label:'Reconstruction Need', val:'Unknown',    change:'Post-conflict',       dir:'neutral'},
    ],
    econOverview:`${name} is creating economic disruption in ${loc} and surrounding regions. FDI is likely to contract as investor confidence falls. Commodity supply chains in the region should be monitored. Refresh to pull live economic reporting from news sources — figures will auto-update.`,
    side1Allies:[
      {country:'Primary backers',    role:'Political support — monitoring'},
      {country:'Arms suppliers',     role:'Pending news verification'},
      {country:'Diplomatic allies',  role:'UN voting alignment — tracking'},
    ],
    side2Allies:[
      {country:'External supporters', role:'Political backing — monitoring'},
      {country:'Weapons sources',     role:'Pending news verification'},
      {country:'Regional partners',   role:'Geopolitical alignment — tracking'},
    ],
    shortTerm:`${name} is in active phase. Expect continued fighting in ${loc} over the next 30 days unless a ceasefire is brokered. Refresh for the latest 30-day outlook from news sources.`,
    mediumTerm:`3–6 month outlook: stalemate or negotiated freeze most likely if neither ${s1} nor ${s2} achieves decisive advantage. External pressure from regional powers will be key.`,
    wildcards:`Surprise third-party intervention. Sudden leadership change in ${s1} or ${s2}. Economic collapse forcing one side to negotiate. Weapons of mass disruption used.`,
    outcome:`Conflict outcome unclear — tracking live. Most conflicts of this type resolve via negotiated settlement or frozen front line within 6–18 months.`,
    connectedTo:[], news:[],
    _query:query||name
  };
}

// Merge custom wars from localStorage on init
(function mergeCustomWars(){
  const customs=loadCustomWars();
  customs.forEach(cw=>{
    if(!S.wars.find(w=>w.id===cw.id)){
      // Rebuild TRADING + RUMORS for this custom war (makeWarShell does it as a side-effect)
      makeWarShell(cw.name,cw.location,cw.side1Name,cw.side2Name,cw._query,cw.id);
      // Now push the saved war data (overrides shell fields with persisted data)
      S.wars.push(cw);
      if(cw._query)NEWS_QUERIES[cw.id]=cw._query;
    }
  });
})();


async function fetchMarkets(){
  S.mktStatus='loading';render();
  const fmt=n=>n>=10000?n.toLocaleString('en',{maximumFractionDigits:0}):n>=100?n.toFixed(1):n.toFixed(2);
  const results=await Promise.allSettled(MARKETS.map(m=>fetchOneSym(m.sym)));
  S.markets=MARKETS.map((m,i)=>{
    const r=results[i];
    if(r.status==='fulfilled'&&r.value){
      const{p,chgPct}=r.value;
      return{...m,val:m.u+fmt(p)+m.s,chg:(chgPct>=0?'+':'')+chgPct.toFixed(2)+'%',dir:chgPct>0?'up':chgPct<0?'dn':'na',live:true};
    }
    return{...m,val:'—',chg:'—',dir:'na',live:false};
  });
  const anyLive=S.markets.some(m=>m.live);
  S.mktStatus=anyLive?'loaded':'error';
  // Compute dynamic risk adjustments from live market data
  if(anyLive){
    const get=(lbl)=>S.markets.find(m=>m.lbl===lbl);
    const vixM=get('VIX Fear'),oilM=get('Brent Crude'),spM=get('S&P 500'),gasM=get('Nat Gas'),goldM=get('Gold');
    const vix=vixM?.live?parseFloat(vixM.val)||20:20;
    const oilChg=oilM?.live?parseFloat(oilM.chg)||0:0;
    const spChg=spM?.live?parseFloat(spM.chg)||0:0;
    const gasChg=gasM?.live?parseFloat(gasM.chg)||0:0;
    // VIX fear premium: adds to all wars
    const vixBonus=vix>35?15:vix>25?8:vix>20?3:0;
    // Per-war adjustments
    const BASE=TRADING;
    Object.keys(BASE).forEach(id=>{
      const base=BASE[id].risk||50;
      let adj=base+vixBonus;
      if(id==='iran-us-israel'){adj+=Math.max(0,oilChg*0.8);adj+=Math.max(0,-spChg*0.5);}
      else if(id==='ukraine-russia'){adj+=Math.max(0,gasChg*0.6);adj+=Math.max(0,oilChg*0.3);}
      else if(id==='yemen-houthis'){adj+=Math.max(0,oilChg*0.5);}
      else if(id==='drc-m23'){adj+=vix>25?5:0;}
      // Only update if not yet set by AI refresh
      if(!S.warRisk[id])S.warRisk[id]=Math.max(0,Math.min(100,Math.round(adj)));
    });
  }
  render();
}

// ── RSS parser ──
function parseRSS(xml){
  if(!xml)return[];
  try{
    const doc=new DOMParser().parseFromString(xml,'text/xml');
    return Array.from(doc.querySelectorAll('item')).slice(0,8).map(i=>{
      const src=i.querySelector('source')?.textContent?.trim()||'';
      let title=i.querySelector('title')?.textContent||'';
      if(src)title=title.replace(new RegExp('\\s*-\\s*'+src.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'$'),'').trim();
      else title=title.replace(/\s-\s[^-]+$/,'').trim();
      return{title,link:i.querySelector('link')?.textContent||'#',date:i.querySelector('pubDate')?.textContent||'',source:src,tier:srcTier(src)};
    });
  }catch(e){return[];}
}

// ── Fetch one RSS feed — direct first (works in Chrome extension), then proxies ──
async function fetchNewsForWar(q){
  const u=`https://news.google.com/rss/search?q=${encodeURIComponent(q)}&hl=en-US&gl=US&ceid=US:en`;
  const mapRss2json=d=>(d.items||[]).slice(0,10).map(i=>({
    title:(i.title||'').replace(/\s-\s[^-]+$/,'').trim(),
    link:i.link||'#',date:i.pubDate||'',source:i.author||'',tier:srcTier(i.author||'')
  }));
  const attempts=[
    // 1. Direct fetch — works in Chrome extension (host_permissions bypass CORS)
    ()=>fetch(u,{signal:AbortSignal.timeout(7000)}).then(r=>{if(!r.ok)throw 0;return r.text();}).then(x=>parseRSS(x)),
    // 2. rss2json API — free tier, sometimes works
    ()=>fetch(`https://api.rss2json.com/v1/api.json?rss_url=${encodeURIComponent(u)}`,{signal:AbortSignal.timeout(8000)}).then(r=>{if(!r.ok)throw 0;return r.json();}).then(mapRss2json),
    // 3. allorigins raw proxy
    ()=>fetch(`https://api.allorigins.win/raw?url=${encodeURIComponent(u)}`,{signal:AbortSignal.timeout(8000)}).then(r=>{if(!r.ok)throw 0;return r.text();}).then(x=>parseRSS(x)),
    // 4. corsproxy.io
    ()=>fetch(`https://corsproxy.io/?${encodeURIComponent(u)}`,{signal:AbortSignal.timeout(8000)}).then(r=>{if(!r.ok)throw 0;return r.text();}).then(x=>parseRSS(x)),
  ];
  for(const fn of attempts){
    try{const items=await fn();if(items&&items.length)return items;}catch(e){}
  }
  return[];
}

// ── Fetch one market symbol — direct first, then proxy ──
async function fetchOneSym(sym){
  const base=`https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(sym)}?range=1d&interval=1m&includePrePost=false`;
  const attempts=[
    // Direct — works in Chrome extension
    ()=>fetch(base,{signal:AbortSignal.timeout(7000)}),
    // Proxy fallbacks for standalone HTML
    ()=>fetch(`https://api.allorigins.win/raw?url=${encodeURIComponent(base)}`,{signal:AbortSignal.timeout(8000)}),
    ()=>fetch(`https://corsproxy.io/?${encodeURIComponent(base)}`,{signal:AbortSignal.timeout(8000)}),
  ];
  for(const fn of attempts){
    try{
      const r=await fn();
      if(!r.ok)continue;
      const d=await r.json();
      const meta=d?.chart?.result?.[0]?.meta;
      if(!meta)continue;
      const p=meta.regularMarketPrice??meta.previousClose;
      const prev=meta.chartPreviousClose||meta.previousClose||p;
      if(p==null)continue;
      const chgPct=prev?((p-prev)/prev*100):0;
      return{p,chgPct};
    }catch(e){}
  }
  return null;
}

// ── Refresh — Google News + Yahoo Finance, no API key ──
async function doRefresh(){
  S.refreshing=true;S.error=null;S.success=null;
  S.refreshMsg='Fetching news…';

  // Fetch all 8 news feeds in parallel
  const entries=Object.entries(NEWS_QUERIES);
  const results=await Promise.allSettled(entries.map(([,q])=>fetchNewsForWar(q)));
  const newsMap={};
  entries.forEach(([wid],i)=>{
    newsMap[wid]=results[i].status==='fulfilled'?results[i].value:[];
  });
  S.wars.forEach(w=>{w.news=newsMap[w.id]||[];});
  const nLoaded=Object.values(newsMap).filter(a=>a.length>0).length;

  // Re-enrich any custom wars that got fresh news
  const customsWithNews=S.wars.filter(w=>w.custom&&newsMap[w.id]?.length);
  for(const w of customsWithNews){
    await enrichWarFromSources(w, newsMap[w.id]);
  }

  // Fetch all market data
  await fetchMarkets();

  S.lastRefresh=new Date();
  S.refreshing=false;S.refreshMsg='';
  // Snapshot scenario probabilities for history tracking
  snapshotScenarios();
  S.error=nLoaded===0?'All news feeds failed — check your connection':null;
  S.success=`Updated ${S.lastRefresh.toLocaleTimeString()} · ${nLoaded}/8 news feeds · markets ${S.mktStatus==='loaded'?'● live':'unavailable'}`;
  render();
}




// ── DETAIL TAB ── (tab bar ALWAYS renders — this was the bug)
function renderTab(war){
  const t=S.detailTab;
  const TABS=[
    {id:'overview',   lbl:'Overview'},
    {id:'trading',    lbl:'📈 Trading',  cls:'tr'},
    {id:'news',       lbl:'📡 News',     cls:'nt'},
    {id:'rumors',     lbl:'⚠ Rumors',   cls:'rt'},
    {id:'casualties', lbl:'Casualties'},
    {id:'military',   lbl:'Military'},
    {id:'leaders',    lbl:'Leaders'},
    {id:'economics',  lbl:'Economics'},
    {id:'alliances',  lbl:'Alliances'},
    {id:'analyst',    lbl:'Analyst'},
    {id:'connections',lbl:'⇌ Links',    cls:'ct'},
  ];
  const tabBar=TABS.map(tab=>{
    const n=tab.id==='news'?war.news?.length:tab.id==='rumors'?(RUMORS[war.id]||[]).length:0;
    const lbl=n?`${tab.lbl} (${n})`:tab.lbl;
    return`<button class="dtab${tab.cls?' '+tab.cls:''}${t===tab.id?' act':''}" data-tab="${tab.id}">${lbl}</button>`;
  }).join('');

  let body='';
  if(t==='overview') body=`<div class="prose"><p>${war.recentDev||war.oneLiner||'—'}</p></div>${renderSourcePanel(war.id)}`;

  else if(t==='trading'){
    const td=TRADING[war.id]||{signals:[],sanctions:[],note:'',risk:50,scenarios:[]};
    const sigDir={long:'LONG',short:'SHORT',watch:'WATCH',avoid:'AVOID'};
    const sigCls={long:'sig-long',short:'sig-short',watch:'sig-watch',avoid:'sig-avoid'};
    const risk=S.warRisk[war.id]??td.risk??50;
    const riskLabel=risk>=80?'CRITICAL':risk>=60?'HIGH':risk>=40?'ELEVATED':risk>=20?'LOW':'MINIMAL';
    const riskCol=risk>=80?'var(--red)':risk>=60?'var(--orange)':risk>=40?'var(--amber)':'var(--green)';
    body=`
    <div class="risk-bar-wrap trcard" style="margin-bottom:10px">
      <div class="trcard-title">Market Risk Level</div>
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:4px">
        <div style="flex:1">
          <div class="risk-track"><div class="risk-needle" style="left:${risk}%"></div></div>
          <div class="risk-labels"><span>Minimal</span><span>Low</span><span>Elevated</span><span>High</span><span>Critical</span></div>
        </div>
        <div style="font-family:'Courier New',monospace;font-weight:700;font-size:13px;color:${riskCol};flex-shrink:0">${riskLabel} (${risk}/100)</div>
      </div>
    </div>
    ${(S.warTradingNote[war.id]||td.note)?`<div class="note-box"><strong>📊 Analyst Context</strong>${S.warTradingNote[war.id]?` <span style="font-size:9px;font-family:'Courier New',monospace;color:var(--teal)">[AI UPDATED]</span>`:''} — ${S.warTradingNote[war.id]||td.note}</div>`:''}
    <div class="trgrid">
      <div class="trcard">
        <div class="trcard-title">Trading Signals</div>
        ${(td.signals||[]).map(s=>`<div class="signal">
          <span class="sig-dir ${sigCls[s.dir]||'sig-watch'}">${sigDir[s.dir]||s.dir.toUpperCase()}</span>
          <div class="sig-text">
            <b>${s.asset}</b>
            ${s.tickers?.length?`<div class="sig-tickers">${s.tickers.map(t=>`<span class="ticker-tag">${t}</span>`).join('')}</div>`:''}
            <div class="sig-sub" style="margin-top:3px">${s.reason}</div>
          </div>
        </div>`).join('')}
      </div>
      <div class="trcard">
          <div class="trcard-title">Active Sanctions</div>
          ${(td.sanctions||[]).map(s=>`<div class="sanc-item">
            <div><div class="sanc-target">${s.target}</div><div class="sanc-by">${s.by}</div></div>
            <span class="sanc-status ${s.status==='act'?'ss-act':s.status==='new'?'ss-new':'ss-par'}">${s.status==='act'?'ACTIVE':s.status==='new'?'NEW':'PARTIAL'}</span>
          </div>`).join('')}
        </div>
    </div>`;
  }

  else if(t==='news'){
    const n=war.news||[];
    body=`<div class="src-key">
      <span class="src-key-lbl">Source credibility:</span>
      <span class="src sh">✓ HIGH</span><span class="src sm">MEDIA</span><span class="src sl">BIASED</span><span class="src ss">⚠ STATE</span>
    </div>
    ${n.length===0?`<div class="no-content">No news loaded — click ↺ Refresh Intelligence to pull from Google News</div>`
    :n.map(a=>{
      const tc={h:'sh',m:'sm',l:'sl',s:'ss'}[a.tier]||'sm';
      const dt=a.date?new Date(a.date).toLocaleDateString('en-US',{month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'}):'';
      return`<div class="nitem"><div class="nbullet"></div><div>
        <div class="ntit"><a href="${a.link}" target="_blank" rel="noopener">${a.title}</a></div>
        <div class="nmeta">${a.source?`<span class="src ${tc}">${a.tier==='h'?'✓ ':a.tier==='s'?'⚠ ':''}${a.source}</span>`:''}${dt?`<span class="ndate">${dt}</span>`:''}</div>
      </div></div>`;
    }).join('')}`;
  }

  else if(t==='rumors'){
    const rs=(RUMORS[war.id]||[]);
    const scls={unconfirmed:'rsu',disputed:'rsd',debunked:'rsx',confirmed:'rsc'};
    const slbl={unconfirmed:'Unconfirmed',disputed:'Disputed',debunked:'Debunked',confirmed:'Confirmed'};
    body=`<div class="rumor-hdr"><strong>⚠ Rumor Tracker</strong> — Claims circulating but unverified. Status reflects current intelligence / media assessment. Treat UNCONFIRMED items with caution.</div>
    ${rs.length===0?`<div class="no-content">No tracked rumors for this conflict.</div>`
    :rs.map(r=>`<div class="rcard ${r.s}">
      <div class="rtop"><span class="rs ${scls[r.s]||'rsu'}">${slbl[r.s]||r.s}</span><div class="rclaim">${r.c}</div></div>
      <div class="rmeta"><span class="rsrc">📡 ${r.src}</span><span>${r.d}</span></div>
    </div>`).join('')}`;
  }

  else if(t==='casualties'){
    body=`<div class="sgrid">${(war.casualties||[]).map(c=>`<div class="scard"><div class="slbl">${c.label}</div><div class="sval${c.cls?' '+c.cls:''}">${c.val}</div></div>`).join('')}</div>
    ${war.casualtyNote?`<p style="font-family:'Courier New',monospace;font-size:10px;color:var(--text2);padding:7px 11px;background:var(--bg3);border-radius:4px;border-left:3px solid var(--muted);line-height:1.7">ℹ ${war.casualtyNote}</p>`:''}`;
  }

  else if(t==='military'){
    body=`<div class="tcol" style="margin-bottom:11px">
      <div class="advbox"><div class="advtitle" style="color:#60a5fa">◀ ${war.side1Name} ADVANTAGES</div>${(war.side1Adv||[]).map(a=>`<div class="advitem"><span style="color:#60a5fa">▸</span>${a}</div>`).join('')}</div>
      <div class="advbox"><div class="advtitle" style="color:#f87171">${war.side2Name} ADVANTAGES ▶</div>${(war.side2Adv||[]).map(a=>`<div class="advitem"><span style="color:#f87171">▸</span>${a}</div>`).join('')}</div>
    </div><div class="stitle">Recent Developments</div><div class="prose"><p>${war.recentDev||''}</p></div>`;
  }

  else if(t==='leaders'){
    body=`<div class="lgrid">${(war.leaders||[]).map(l=>`<div class="lcard"><span class="lside ${l.side==='1'?'ls1':'ls2'}">${l.side==='1'?war.side1Name:war.side2Name}</span><div class="lname">${l.name}</div><div class="ltit">${l.title}</div><div class="ldesc">${l.bio}</div></div>`).join('')}</div>`;
  }

  else if(t==='economics'){
    const econUpdated=S.lastRefresh&&war.econMetrics?.length;
    body=`${econUpdated?`<div class="okbanner" style="margin-bottom:8px">✓ Economics updated from live news — ${S.lastRefresh.toLocaleTimeString()}</div>`:'<div class="nbanner" style="margin-bottom:8px">Baseline data shown — hit ↺ Refresh to update from live news</div>'}
    <div class="sgrid">${(war.econMetrics||[]).map(m=>`<div class="scard"><div class="slbl">${m.label}</div><div class="sval">${m.val}</div><div style="font-size:10px;margin-top:2px;${m.dir==='up'?'color:var(--green)':m.dir==='down'?'color:var(--red)':'color:var(--muted)'}">${m.change}</div></div>`).join('')}</div>
    <div class="prose"><p>${war.econOverview||''}</p></div>`;
  }

  else if(t==='alliances'){
    body=`<div class="agrid">
      <div class="aside"><div class="atit bl">${war.side1Name}</div>${(war.side1Allies||[]).map(a=>`<div class="aitem"><span>${a.country}</span><span class="arole">${a.role}</span></div>`).join('')}</div>
      <div class="aside"><div class="atit rd">${war.side2Name}</div>${(war.side2Allies||[]).map(a=>`<div class="aitem"><span>${a.country}</span><span class="arole">${a.role}</span></div>`).join('')}</div>
    </div>`;
  }

  else if(t==='analyst'){
    const td2=TRADING[war.id]||{scenarios:[]};
    body=`
    <div class="trgrid" style="margin-bottom:10px">
      <div class="trcard">
        <div class="trcard-title">Scenario Outcomes</div>
        <table class="scen-table"><thead><tr><th>Scenario</th><th>Prob</th><th>Market Impact</th></tr></thead><tbody>
        ${(td2.scenarios||[]).map(sc=>`<tr><td class="sn">${sc.name}</td><td><span class="sp ${sc.cls}">${sc.prob}</span></td><td style="color:var(--text2)">${sc.mkt}</td></tr>`).join('')}
        </tbody></table>
      </div>
      <div style="display:flex;flex-direction:column;gap:8px">
        <div class="ac" style="margin:0"><div class="ah">⚡ 30-Day Outlook</div><div class="ab">${war.shortTerm||'—'}</div></div>
        <div class="ac g" style="margin:0"><div class="ah">✓ Most Likely Outcome</div><div class="ab">${war.outcome||'—'}</div></div>
      </div>
    </div>
    <div class="ac"><div class="ah">📊 3–6 Month Scenario</div><div class="ab">${war.mediumTerm||'—'}</div></div>
    <div class="ac r"><div class="ah">🎲 Wildcards</div><div class="ab">${war.wildcards||'—'}</div></div>`;
  }

  else if(t==='connections'){
    const conns=war.connectedTo||[];
    body=conns.length===0?`<div class="no-content">No connections identified.</div>`
    :`<p style="font-size:12px;color:var(--text2);margin-bottom:10px;line-height:1.7"><strong style="color:var(--purple)">${conns.length} active link${conns.length!==1?'s':''}</strong> to other conflicts.</p>
    ${conns.map(c=>{
      const bgs=(c.types||[]).map(tp=>TYPE_MAP[tp]?`<span class="cbadge ${TYPE_MAP[tp].cls}">${TYPE_MAP[tp].label}</span>`:'').join('');
      const sc=c.strength==='direct'?'csd':c.strength==='indirect'?'csi':'cse';
      return`<div class="wccard"><div style="color:var(--purple);font-size:15px;flex-shrink:0;margin-top:2px">⇌</div><div><div class="wctarget">${c.warName}</div><div class="wcdesc">${c.desc}</div><div class="cbadges">${bgs}${c.strength?`<span class="cstr ${sc}">${c.strength}</span>`:''}</div></div></div>`;
    }).join('')}`;
  }

  // ALWAYS wrap in .dp with .dtabs — this fixes the tab disappearing bug
  return`<div class="dp"><div class="dtabs">${tabBar}</div><div class="tab-body">${body}</div></div>`;
}

// ── War view ──
function renderWar(){
  const war=S.wars[S.activeWar];if(!war)return'';
  const s1=Math.min(Math.max(war.side1Score||50,8),92);
  return`
    <div class="wh">
      <div class="wn">${war.name}</div>
      <div class="wmeta">
        <span class="wstat ${war.status.includes('Active')?'sa':'sf'}">${war.status}</span>
        <span class="wmi"><b>📍</b>${war.location}</span>
        <span class="wmi"><b>📅</b>${war.startDate}</span>
        ${war.dayCount?`<span class="wmi"><b>Day</b> ${war.dayCount}</span>`:''}
        ${war.connectedTo?.length?`<span class="wmi" style="color:var(--purple)"><b style="color:var(--purple)">⇌</b>${war.connectedTo.length} links</span>`:''}
        ${war.news?.length?`<span class="wmi" style="color:var(--green)"><b style="color:var(--green)">📡</b>${war.news.length}</span>`:''}
        ${(RUMORS[war.id]||[]).length?`<span class="wmi" style="color:var(--orange)"><b style="color:var(--orange)">⚠</b>${(RUMORS[war.id]||[]).length} rumors</span>`:''}
      </div>
      <div class="liner">${war.oneLiner}</div>
    </div>
    <div class="bsec">
      <div class="stitle">Tactical Advantage</div>
      <div class="brow"><span class="blab s1">${war.side1Name}</span><span class="blab s2">${war.side2Name}</span></div>
      <div class="bbar"><div class="bf1" style="width:${s1}%">${s1}%</div><div class="bf2">${100-s1}%</div></div>
      <div style="display:flex;justify-content:space-between;margin-top:4px">
        <span style="font-family:'Courier New',monospace;font-size:9px;color:var(--blue)">← ${war.side1Name}</span>
        <span style="font-family:'Courier New',monospace;font-size:9px;color:#f87171">${war.side2Name} →</span>
      </div>
      ${war.battleAssessment?`<p class="bassess">${war.battleAssessment}</p>`:''}
    </div>
    ${renderTab(war)}`;
}

// ── Connections view ──
function renderConns(){
  const byT={};Object.keys(TYPE_MAP).forEach(k=>{byT[k]=GLOBAL_CONNECTIONS.filter(c=>c.types.includes(k)).length;});
  return`<div class="chdr">
    <div style="font-weight:800;font-size:17px;color:var(--white);margin-bottom:5px">⇌ Inter-War Connections</div>
    <div style="font-size:13px;color:var(--text2);margin-bottom:10px"><strong style="color:var(--purple)">${GLOBAL_CONNECTIONS.length} active linkages</strong> — weapon flows, shared actors, economic ties, proxy chains.</div>
    <div class="cbadges">${Object.entries(TYPE_MAP).map(([k,v])=>`<span class="cbadge ${v.cls}">${v.label}: ${byT[k]||0}</span>`).join('')}</div>
  </div>
  <div class="cgrid">${GLOBAL_CONNECTIONS.map(c=>{
    const bgs=(c.types||[]).map(tp=>TYPE_MAP[tp]?`<span class="cbadge ${TYPE_MAP[tp].cls}">${TYPE_MAP[tp].label}</span>`:'').join('');
    const sc=c.str==='direct'?'csd':c.str==='indirect'?'csi':'cse';
    return`<div class="ccard"><div class="cwars"><span class="cwname">${c.w1}</span><span class="carrow">⇌</span><span class="cwname">${c.w2}</span></div><div class="cbadges">${bgs}${c.str?`<span class="cstr ${sc}">${c.str}</span>`:''}</div><div class="cdesc">${c.desc}</div></div>`;
  }).join('')}</div>`;
}

// ── Render ──
function render(){
  const app=document.getElementById('app');
  const hi=S.wars.filter(w=>w.intensity==='high').length;
  const ticker=[...S.wars,...S.wars].map(w=>`<span class="ti">${w.name} — ${w.status}<span class="ts"> ◆ </span></span>`).join('');
  const isDark=S.theme==='dark';
  const warTabs=S.wars.map((w,i)=>{
    const ng=w.news?.length?`<span style="color:var(--green);font-size:8px">●</span>`:'';
    const rg=(RUMORS[w.id]||[]).length?`<span style="color:var(--orange);font-size:8px">!</span>`:'';
    const customBadge=w.custom?`<span class="custom-badge">CUSTOM</span>`:'';
    const isAct=!S.showConns&&S.activeWar===i;
    return`<div class="ntab-wrap"><button class="ntab${isAct?' act':''}" data-war="${i}"><span class="idot i${w.intensity[0]}"></span>${w.name}${customBadge}${ng}${rg}</button><button class="rm-war" data-rmwar="${i}" title="Remove conflict">✕</button></div>`;
  }).join('');

  const vixVal=S.markets.find(m=>m.lbl==='VIX Fear');
  const vixNum=vixVal?.live?parseFloat(vixVal.val)||0:0;
  const vixClr=vixNum>=35?'var(--red)':vixNum>=25?'var(--orange)':vixNum>=18?'var(--amber)':'var(--green)';
  const mktHtml=S.mktStatus==='loading'?`<div class="mbar"><div class="mload"><span class="spin"></span>Loading market data…</div></div>`
    :`<div class="mbar">${S.markets.map(m=>{
      const isVix=m.lbl==='VIX Fear';
      const vixLabel=isVix&&m.live?(vixNum>=35?' EXTREME':vixNum>=25?' HIGH':vixNum>=18?' ELEV':''):'' ;
      return`<div class="mi" style="${isVix?`border-left:2px solid ${vixClr};`:''}"><div class="mlbl" style="${isVix?`color:${vixClr}`:''}">${m.lbl}${vixLabel}</div><div class="mrow"><span class="mv" style="${isVix&&m.live?`color:${vixClr}`:''}">${m.val}</span><span class="mc ${m.dir}">${m.chg}</span></div></div>`;
    }).join('')}<div class="mlive">${S.mktStatus==='loaded'?`<span style="color:var(--green)">● LIVE ${S.lastRefresh?S.lastRefresh.toLocaleTimeString():''}</span>`:`<span style="color:var(--muted)">● NO DATA</span>`}</div></div>`;

  const cpHtml=`<div class="cpbar">${CHOKEPOINTS.map(p=>`<div class="cpi"><span class="cpname">${p.name}</span><span class="cpstatus ${p.cls}">${p.status}</span><span class="cppct">${p.pct}</span></div>`).join('')}</div>`;

  app.innerHTML=`
    <div class="hdr">
      <div class="hdr-l">
        <div class="logo">GLOBAL<span>WAR</span>WATCH</div>
        <span class="bdg bi">Markets & Intel</span>
        <span class="bdg bl">● Live</span>
        ${S.refreshing?`<span class="bdg bu">↺ Updating</span>`:''}
      </div>
      <div class="hdr-r">
        ${S.refreshing?`<span class="bdg bu" style="animation:pulse 1s infinite"><span class="spin"></span>${S.refreshMsg||'Updating…'}</span>`:`<span class="bdg bl" style="font-size:9px">↺ ${S.lastRefresh?'Updated '+S.lastRefresh.toLocaleTimeString():'Loading…'}</span>`}
        <button class="hbtn" id="tbtn">${isDark?'☀ Light':'🌙 Dark'}</button>
      </div>
    </div>
    ${mktHtml}
    ${cpHtml}
    <div class="tick-wrap"><div class="ticker">${ticker}</div></div>

    <div class="sbar">
      <span class="si">Conflicts: <strong>${S.wars.length}</strong></span><span class="sdv">|</span>
      <span class="si">High Intensity: <strong style="color:var(--red)">${hi}</strong></span><span class="sdv">|</span>
      <span class="si">Est. 2026 Deaths: <strong style="color:var(--amber)">300K+</strong></span><span class="sdv">|</span>
      <span class="si" style="color:var(--purple)">⇌ <strong style="color:var(--purple)">${GLOBAL_CONNECTIONS.length} links</strong></span><span class="sdv">|</span>
      <span class="si" style="color:var(--teal)">📈 <strong style="color:var(--teal)">${S.markets.find(m=>m.lbl==='Brent Crude')?.val||'—'} Brent · ${S.markets.find(m=>m.lbl==='Gold')?.val||'—'} Gold</strong></span>
    </div>
    <div class="wnav">
      ${warTabs}
      <button class="ntab${S.showConns?' pact':''}" id="ctab">⇌ All Connections <span class="cpill">${GLOBAL_CONNECTIONS.length}</span></button>
      <button class="add-war-btn" id="addwarbtn">＋ Add Conflict</button>
    </div>
    <div class="main">
      ${S.error?`<div class="errbanner">⚠ ${S.error}</div>`:''}
      ${S.success?`<div class="okbanner">✓ ${S.success}</div>`:''}
      <div class="nbanner">
        <span>${S.lastRefresh?`Last refreshed: ${S.lastRefresh.toLocaleTimeString()} · Google News powered`:'Loading live data… auto-refreshes every 5 minutes'}</span>
        <span style="color:var(--muted);font-size:9px">No API key required · Google News + Yahoo Finance</span>
      </div>
      ${S.showConns?renderConns():renderWar()}
    </div>
    ${S.showAddModal?`<div class="overlay" id="awov">
      <div class="modal wide">
        <h2>＋ Add Conflict</h2>
        <span class="mtag">CUSTOM WAR</span>
        <p>Enter the conflict details below. GlobalWarWatch will fetch live news automatically.</p>
        <label class="mlbl">Conflict Name *</label>
        <input class="minput" id="aw-name" placeholder="e.g. Taiwan Strait Crisis" value="${S.addForm?.name||''}"/>
        <div class="mrow2">
          <div><label class="mlbl">Location</label><input class="minput" id="aw-loc" placeholder="e.g. Taiwan, Pacific" value="${S.addForm?.loc||''}"/></div>
          <div><label class="mlbl">Intensity</label>
            <select class="minput" id="aw-int" style="cursor:pointer">
              <option value="high" ${S.addForm?.int==='high'?'selected':''}>High</option>
              <option value="medium" ${(!S.addForm||S.addForm?.int==='medium')?'selected':''}>Medium</option>
              <option value="low" ${S.addForm?.int==='low'?'selected':''}>Low</option>
            </select>
          </div>
        </div>
        <div class="mrow2">
          <div><label class="mlbl">Side 1 Name</label><input class="minput" id="aw-s1" placeholder="e.g. Taiwan / USA" value="${S.addForm?.s1||''}"/></div>
          <div><label class="mlbl">Side 2 Name</label><input class="minput" id="aw-s2" placeholder="e.g. China (PRC)" value="${S.addForm?.s2||''}"/></div>
        </div>
        <label class="mlbl">News Search Query (auto-fills from name)</label>
        <input class="minput" id="aw-q" placeholder="e.g. Taiwan China military 2026" value="${S.addForm?.q||''}"/>
        <div class="mnote">News will be fetched from Google News using this search query. You can refine it for better results.</div>
        <div class="mbtns">
          <button class="mcan" id="awcan">Cancel</button>
          <button class="msub" id="awsub">Add & Fetch News →</button>
        </div>
      </div>
    </div>`:''}
  `;

  // Events
  document.getElementById('tbtn')?.addEventListener('click',()=>{S.theme=S.theme==='dark'?'light':'dark';document.documentElement.setAttribute('data-theme',S.theme);localStorage.setItem('gww_theme',S.theme);render();});
  document.getElementById('ctab')?.addEventListener('click',()=>{S.showConns=true;render();});
  document.querySelectorAll('.ntab[data-war]').forEach(b=>b.addEventListener('click',()=>{S.activeWar=parseInt(b.dataset.war);S.showConns=false;S.detailTab='overview';render();}));
  document.querySelectorAll('[data-tab]').forEach(b=>b.addEventListener('click',()=>{S.detailTab=b.dataset.tab;render();}));

  // ── Remove war ──
  document.querySelectorAll('.rm-war[data-rmwar]').forEach(btn=>btn.addEventListener('click',e=>{
    e.stopPropagation();
    const idx=parseInt(btn.dataset.rmwar);
    const war=S.wars[idx];
    if(!war)return;
    if(!confirm(`Remove "${war.name}" from GlobalWarWatch?`))return;
    delete NEWS_QUERIES[war.id];
    S.wars.splice(idx,1);
    if(S.activeWar>=S.wars.length)S.activeWar=Math.max(0,S.wars.length-1);
    saveCustomWars();
    render();
  }));

  // ── Add war — open modal ──
  document.getElementById('addwarbtn')?.addEventListener('click',()=>{
    S.showAddModal=true;
    S.addForm={name:'',loc:'',s1:'',s2:'',q:'',int:'medium'};
    render();
  });

  // ── Add war modal — cancel / backdrop ──
  document.getElementById('awcan')?.addEventListener('click',()=>{S.showAddModal=false;render();});
  document.getElementById('awov')?.addEventListener('click',e=>{if(e.target.id==='awov'){S.showAddModal=false;render();}});

  // ── Add war — name auto-fills query ──
  document.getElementById('aw-name')?.addEventListener('input',e=>{
    const n=e.target.value.trim();
    const qEl=document.getElementById('aw-q');
    if(qEl&&!qEl.dataset.touched)qEl.value=n+' war 2026';
  });
  document.getElementById('aw-q')?.addEventListener('input',e=>{e.target.dataset.touched='1';});

  // ── Add war — submit ──
  document.getElementById('awsub')?.addEventListener('click',async()=>{
    const name=(document.getElementById('aw-name')?.value||'').trim();
    if(!name){document.getElementById('aw-name')?.focus();return;}
    const loc=(document.getElementById('aw-loc')?.value||'').trim();
    const s1=(document.getElementById('aw-s1')?.value||'').trim();
    const s2=(document.getElementById('aw-s2')?.value||'').trim();
    const q=(document.getElementById('aw-q')?.value||name+' war 2026').trim();
    const intensity=document.getElementById('aw-int')?.value||'medium';
    const id='custom-'+name.toLowerCase().replace(/[^a-z0-9]+/g,'-').slice(0,40)+'-'+Date.now().toString(36);
    const war=makeWarShell(name,loc||'Unknown',s1,s2,q,id);
    war.intensity=intensity;
    NEWS_QUERIES[id]=q;
    S.wars.push(war);
    S.activeWar=S.wars.length-1;
    S.showAddModal=false;S.showConns=false;S.detailTab='news';
    saveCustomWars();
    render();
    // Fetch news + enrich from Wikipedia/headlines
    S.refreshMsg=`Loading news for ${name}…`;S.refreshing=true;render();
    const items=await fetchNewsForWar(q);
    const w=S.wars.find(x=>x.id===id);
    if(w){
      w.news=items||[];
      S.refreshMsg=`Enriching ${name} from Wikipedia…`;render();
      await enrichWarFromSources(w, items);
    }
    S.refreshing=false;S.refreshMsg='';
    S.success=`${name} added · ${items.length} news articles loaded · intelligence populated from Wikipedia`;
    render();
  });

}

// ── Auto-poll: markets every 60s, news every 5min ──
let _newsTimer=null, _mktTimer=null;
async function startPolling(){
  // Initial load
  await doRefresh();
  // Markets: refresh every 60 seconds
  _mktTimer=setInterval(()=>{
    fetchMarkets();
  }, 60_000);
  // News: refresh every 5 minutes
  _newsTimer=setInterval(()=>{
    doRefresh();
  }, 5*60_000);
}

render();
startPolling();