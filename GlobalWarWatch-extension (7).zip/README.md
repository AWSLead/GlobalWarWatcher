# GlobalWarWatch Chrome Extension

Live geopolitical intelligence dashboard tracking 8 active conflicts.
Auto-refreshes news every 5 minutes, markets every 60 seconds. No API key required.

## Install in Chrome

1. Click the green **Code** button → **Download ZIP**
2. Unzip the downloaded file  
3. **Important:** Go *inside* the unzipped folder — you should see `manifest.json`, `popup.html`, `popup.js` and icons directly inside
4. Open Chrome → go to `chrome://extensions`
5. Enable **Developer mode** (toggle top-right)
6. Click **Load unpacked**
7. Select the folder that contains `manifest.json`

## What it tracks
- Iran–US/Israel War (Operation Epic Fury)
- Russia–Ukraine War
- Gaza / Israel–Hamas War
- Yemen / Houthis (Red Sea)
- Sudan Civil War
- Myanmar Civil War
- DRC / Eastern Congo (M23)
- Somalia / Al-Shabaab

## Features
- Live Yahoo Finance market data (Brent, Gold, VIX, S&P 500, and more)
- Google News RSS for all conflicts
- Source credibility ratings per outlet
- Scenario probability tracking with sparklines
- Add custom conflicts — auto-enriched from Wikipedia + news
- Tactical advantage bar that drifts from headline sentiment
- Auto-detected connections between conflicts
